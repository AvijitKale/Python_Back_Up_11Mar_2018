#### This program finds all the duplicate strings in a single string:: 
#### Even though there are more than 1 duplicates, this program will print just one duplicate in the final list


str1 = "ghixabcdfcxbabclfcxbkghixfaaasaghiplnkabc"

#str1 = "yugandharaaddfdyugafdfdfyugandhara"

list1 = []
str2 = ""
str3 = ""
m = 0
count  = len(str1)
for y in range(m ,count,1):
	x = y + 1
	str2 = str3 = ""
	while x < count:
#		print "X: and length", x , len(str1)
		if str1[y] == str1[x] and x <= len(str1):
			str2 = str2 + str1[x]
                	y = y + 1
			flag = True
			if x == (count-1) and len(str2) > 2 and flag:
                                list1.append(str2)
				j = x 
				for i in range(len(str2)):
                                        str1.replace(str1[x], "")
                                        j = j - 1
					count = count -1
                                flag = False
                                m = y

		elif str1[y] != str1[x] and  x <= count:
			if len(str2) > 2 and flag:
                                list1.append(str2)
				j = x- 1
				for i in range(len(str2)):
					str1.replace(str1[x], "")
					j = j - 1
					count = count -1
				flag = False
				m = y
#				print "==========>str1[X] after one list: ", str1[x]
			str2 = ""
#			print "m: ", m
		elif x > (count):
                        y = m
                        break
		x = x + 1


	
print list1
			
			


