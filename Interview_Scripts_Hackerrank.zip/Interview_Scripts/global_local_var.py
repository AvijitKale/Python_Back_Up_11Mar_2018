def h():
       
    a = 3
    print 'Inside h() : ',a
 
# Global scope

a = 2
print 'global : ', a
h()

print 'after: ', a
