first_names = ['Fred', 'George', 'Bill']
last_names = ['Smith', 'Jones', 'Williams']
name_tuple = (first_names, last_names)

first_names.append('Igor')

last_names.append('Dsuza')

print "Printing tuple(first name Igor has been added here too.): ", name_tuple


print "Printing Last Names After adding one more entry: {0}".format(last_names)

print "Printing First Names list: ", first_names
