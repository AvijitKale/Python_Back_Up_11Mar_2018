dir1 = "home/avijit/python/file1"
dir2 = "home/avijit/python/scripts/file2"
dir3 = "home/avijit/python/codes/file3"
dir4 = "home/avijit/python/codes/file4"
dir5 = "home/avijit/python/scripts/file5"

list1 = [dir1, dir2, dir3, dir4 , dir5]

split_paths = []

for i in range(len(list1)):
	split_paths.append(list1[i].split("/"))


print "Split_Paths: ", split_paths



for i in range(len(split_paths)):
	n = i + 1
	for j in range(n,len(split_paths),1):
		k = 0
		common_path = []
		for m in range(min(len(split_paths[i]) ,len(split_paths[j]))):
			if split_paths[i][k] == split_paths[j][k]:
				common_path.append(split_paths[i][k])
				k += 1
		print "i: ", i , "j:", j
		print "/".join(common_path)
#		print common_path



					
		
