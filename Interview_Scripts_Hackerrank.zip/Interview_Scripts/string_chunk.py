str1 = raw_input("Enter the string: ")

str2 = raw_input("Enter the second string: ")

str3 = ""

x = 0

for y in range(len(str1)):
	print "Index of y: ", y, str1[y]
	print "Index of x: ", x, str2[x]
	if str1[y] == str2[x]:
		print "char: ", str2[x]	
		str3 = str3 + str2[x]
		x += 1
		if x == len(str2):
			break	
	else:
		x = 0	
		str3 = ""

print str3

if str2 == str3:
	print "string 2 exists inside str1"
	
else:
	print "String 2 DOES NOT exist inside str1"
		
