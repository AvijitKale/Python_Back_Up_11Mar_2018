alist = [1,2,3,4,5,6,7,8,9]

blist = [14,15,16,17,18,19,10,11,1,2,12,13]

for x in alist:
	if x in blist:
		print "Match Found: {0}".format(x)



