numbers = raw_input("Enter 2 numbers seperated by comma: ")

num = numbers.split(",")

print num[0]

print num[1]

flag = True

n = min(num[0], num[1])

print "Minimum of numbers is : {0}".format(n)


for i in range(2,int(n),1):
	if int(num[0])%i == 0 and int(num[1])%i == 0:
		flag = False
		break

if flag == False:
	print "Both the numbers are NOT coprime since they both are divisible by:  {0}".format(i)
else:
	print "Both the numbers are coprime since there is no common factor between them except 1"
