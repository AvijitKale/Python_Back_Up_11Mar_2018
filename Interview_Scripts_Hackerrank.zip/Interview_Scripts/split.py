num = "10/20"


#num = int(num)

list = []

list = num.split("/")

print int(list[0])

print int(list[1])


