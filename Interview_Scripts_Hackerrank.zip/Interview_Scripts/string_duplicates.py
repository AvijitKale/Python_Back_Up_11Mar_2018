## This script will find out duplicate characters in string EXCEPT SPACE without using any extra buffer 


string1 = raw_input("Enter the string: ")


#count = len(string1)
#print count
#print string1[0]

for x in range(len(string1)):
    for y in range(x+1,len(string1),1):
	if ((string1[x] != ' ') and (string1[x] == string1[y])):
	    print "Character: ", string1[x] ,"positions:%d %d " %( x, y)
	    print "Duplicate Character"



    
