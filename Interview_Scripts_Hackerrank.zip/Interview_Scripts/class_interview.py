class C:
    dangerous = 2

c1 = C()
c2 = C()

print c1.dangerous

c1.dangerous = 3

print c1.dangerous

print c2.dangerous

del c1.dangerous     ## Only Instance Variable got deleted... But C1 object can get the variable value from parent.

print c1.dangerous

C.dangerous = 4

print c1.dangerous
