def prime_check(num):
	flag = True
	if num > 1:
		for n in range(2,num,1):
			if num%n == 0:
				flag = False
				break
				
		if flag:
			print "Number is Prime number"
		else:
			print "Number is NOT Prime since its first divisible by {0}".format(n)
	else:
		print "Number must be greater than 1"

num = input("Enter the number to be checked for prime: ")
prime_check(num)

