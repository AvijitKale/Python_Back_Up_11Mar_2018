def extendList(val,list=None):
    if list is None:
	list = []
    list.append(val)
    return list


def extendList_tricky(val,list=[]):
    list.append(val)
    return list


list1 = extendList(10)
list2 = extendList(123,[])
list3 = extendList('a')


list4 = extendList_tricky(10)
list5 = extendList_tricky(123,[])
list6 = extendList_tricky('a')


print list1
print list2
print list3

print list4
print list5
print list6
