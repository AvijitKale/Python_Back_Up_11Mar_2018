import time

def timeit(method):
	def inside(counter):
		ts = time.time()
		print "start: ", ts
		result =method(counter)
		te = time.time() 
		print "Time taken: ", (te-ts)
		return result
	return inside

@timeit
def fun_time(counter):
	for i in range(counter):
		time.sleep(0.1)
		print "Hello"

fun_time(100)

