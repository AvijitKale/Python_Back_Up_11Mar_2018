import time

def timeit(method):
    def timed(*args, **kw):
        ts = time.time()
        result = method(*args, **kw)
        te = time.time()

	print "Time Taken:{0} ".format(te-ts)
#        print '%r (%r, %r) %2.2f sec' % \
#              (method.__name__, args, kw, te-ts)
        return result

    return timed

@timeit
def f1(count):
	for i in range(count):
		time.sleep(0.1)
#		print "Hello"

f1(100)
