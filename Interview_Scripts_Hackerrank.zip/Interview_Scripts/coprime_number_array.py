m = input("Enter the number to check for coprime: ")

numbers = raw_input("Enter array of numbers seperated by comma: ")

num = numbers.split(",")

coprime_list = []
NO_coprime_list = []

for count in range(len(num)):
	flag = False
	print "count:", int(num[count])
	n = min(int(m) , int(num[count]))
	print "Minimum of these numbers : {0}".format(n)
	for i in range(2,int(n)+1,1):
		if int(m)%i == 0 and int(num[count])%i == 0:
			NO_coprime_list.append(num[count])
			flag = True
			break
		else:
			flag = False
			
	if flag == False:
		coprime_list.append(num[count])


print "List of numbers which are NOT coprime with {0} is : ".format(m)
	
print NO_coprime_list

print "List of numbers which are coprime with {0} is : ".format(m)

print coprime_list


