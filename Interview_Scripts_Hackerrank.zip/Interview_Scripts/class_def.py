###Problem: 
"""	Implement a function DoIt( o,a ) such that the following code:


Object o = SomeClass()
O.first = 'fuzz'
O.second = 'buzz'

print DoIt( o, 'first)
print DoIt(o, 'second')
prints 

fuzz 
buzz  """


class someclass(object):
    first = None
    second = None

o = someclass()
o.first = "FUZZ"
o.second = "BUZZ"


def DoIt(o,name):
    if name == "first":
	return o.first
    elif name == "second":
	return o.second
    else:
        return NULL


print DoIt(o,"first")
print DoIt(o,"second")




