class Parent(object):
    x = 1

class Child1(Parent):
    pass

class Child2(Parent):
    pass

print Parent.x, Child1.x, Child2.x
Child1.x = 2
print Parent.x, Child1.x, Child2.x
Parent.x = 3
print Parent.x, Child1.x, Child2.x    ### Child1.x WILL NOT Change since its defined. 

Child2.x = 4
print Parent.x, Child1.x, Child2.x

Parent.x = 5
print Parent.x, Child1.x, Child2.x
