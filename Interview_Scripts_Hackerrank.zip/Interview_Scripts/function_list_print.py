def f(x,l=[]):
    for i in range(x):
        l.append(i*i)
    return(l) 

print f(2)
print f(4,[3,2,1])
print f(3)


def fun(x,l=[]):
	l.append(x)
	return l


l1= fun(10)

l2=  fun(3,[1,2,3])
l3 =  fun(100)


print l1

print l2

print l3

