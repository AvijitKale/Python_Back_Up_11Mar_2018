alist = [1,3,7,3,12,5,9,12,7,5,8,1,5]

if alist:
    alist.sort()
    last = alist[-1]
    for i in range(len(alist)-2,-1,-1):
	if last == alist[i]:
	    del alist[i]
	else:
	    last = alist[i]


print alist

