def fact(n):

	if n == 0:
		print "1"
		return 1

	else:
		print "n: ", n
		return n * fact(n-1)


n = raw_input("Enter the number to get factorial for :")

print fact(int(n))
