"""
Original List does NOT change when you assign a different list to original

Original List DOES change when you append any parameter to the list inside a function
"""


def reassign(list):
  list = [0, 1]
  print "Inside reassign list: ", list


def append(list):
  list.append(1)

list = [0]
print "Original List: ", list

reassign(list)

print "After calling reassign, Outside of function Back to original: ", list

append(list)

print "After calling append: ", list
