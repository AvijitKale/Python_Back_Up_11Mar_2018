

alist = [1,2,3,4,5,2,3,5,7]

aset = set(alist)

print aset

aset = list(aset)

print aset
