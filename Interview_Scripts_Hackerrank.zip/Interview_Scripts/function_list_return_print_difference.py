def f(x,l=[]):
    l.append(x)
    return l

def fun(x,l=[]):
    l.append(x)
    print l

#### There is a difference in the above 2 functions:  One PRINTS the LIST  and RETURNS the LIST

##  So check out the output of the aboove 2 functions

print "Printing the function with PRINT list in it\n"

#print "When you Print the list in the function it takes blank list for the first time in all given values everywhere"

fun(10)
fun(100,[1,2,3])
fun('a')

print "\n\n\n"


print "Printing the function with RETURN list in it"

# When you store the returned output and then print it one by one
#it saves all the values first and then print them\n"


l1 = f(10)
l2 = f(100,[1,2,3])
l3 = f('a')


print l1

print l2

print l3

