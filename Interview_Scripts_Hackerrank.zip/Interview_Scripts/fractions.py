def fractions(fractions):
	num = fractions[0]
	alist = []
	result = []

	for i in range(1,num+1):
		print fractions[i]
		alist = fractions[i].split("/")

		n = int(alist[0])
		d = int(alist[1])

		print n , d

arr = [4, "123/12","23/25", "34/45" , "23/12"]

fractions(arr)
