string = raw_input("Enter the string and replacing item: ")

lines = string.split(" ")

count  = len(lines)

print lines
 
for i in range(len(lines)):
    if lines[i] == "the":
	print lines[i]
	print "found word: "
	lines[i] = "%"
	print lines[i]

print lines


#print ' '.join(lines)
	
