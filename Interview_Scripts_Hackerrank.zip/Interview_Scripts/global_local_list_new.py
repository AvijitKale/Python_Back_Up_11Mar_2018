def fun(l):
	l.append(30)  ## This value will get appended to Original List: 
	print "Inside: {0}".format(l)
	k = [7,8,9,17]
	l = k
	k.append(10)
	print "Inside Function adding k: {0}".format(k)
	print "Inside Function adding l: {0}".format(l)	
	l.append(20)   ## This value will NOT get appended to Original List outside this function	
	print "Inside Function adding k: {0}".format(k)
        print "Inside Function adding l: {0}".format(l)

if __name__ == '__main__':
	l = [1,2,3,4]
	print "Global :{0}".format(l)
	fun(l)
	print "After : {0}".format(l)
