str1 = raw_input("Enter the first string: ")

str2 = raw_input("Enter second string to be checked for anagram of first string: ")


count = len(str1)

flag = False

k = 0

for j in range(len(str1)):
	if k < len(str2):
		if str1[j] == str2[k]:
			k += 1
			flag = True

		elif str1[j] != str2[k]:
			flag = False
			k = 0
	elif k >= len(str2):
		break	

print flag , k

if k == len(str2) and flag == True:
	print "String is anagram "
				
					
	
		
			
