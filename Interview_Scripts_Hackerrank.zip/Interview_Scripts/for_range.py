alist = []

for x in range(1,10):
    alist.append(range(5))

print alist
