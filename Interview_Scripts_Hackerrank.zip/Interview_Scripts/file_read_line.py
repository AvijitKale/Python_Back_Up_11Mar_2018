fh = open("testfile.txt", "r")


print fh.read(1)

pos = fh.tell()

pos = pos+1

#print len(fh.read())

#count = len(fh.read())

#print count

print fh.read(1) 
	
	
