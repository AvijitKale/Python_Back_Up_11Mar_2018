def long_seq(alist):
	count = 0
	blist = []

	for i in range(len(alist)):
		
				
	print count		
	print blist



alist = [25,3,5,14,9,17,21]
			
long_seq(alist)
		

	
