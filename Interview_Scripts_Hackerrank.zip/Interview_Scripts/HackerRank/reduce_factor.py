def reduce_factor(fractions):

	num = fractions[0]

	result = []
	count = len(fractions)

	for i in range(1,count):
		
		print "fractions[i] ",fractions[i]

		alist = []

		blist = []

		number = fractions[i]

#		number = str(number)

		alist = number.split("/")

		print "alist: ", alist

		numerator = int(alist[0])

		denominator = int(alist[1])

		for j in range(2,denominator+1):
			
			if numerator%j == 0 and denominator%j == 0:
				blist.append(j)

		x = max(blist)
		
		print str(numerator/x)  + "/" +  str(denominator/x)


arr = [5, "66/11" , "105/54" , "126/42" , "100/60" , "150/30"]

reduce_factor(arr)
