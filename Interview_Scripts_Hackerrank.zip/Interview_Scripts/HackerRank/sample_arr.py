
def arr_create(n):

	diff = n + (n-2)

        fixed_diff = diff

	print diff

        arr = []
        for j in range(n-1):
                arr.append(diff)
                diff = diff - 2

        arr.append(fixed_diff)

	print arr


arr_create(5)

