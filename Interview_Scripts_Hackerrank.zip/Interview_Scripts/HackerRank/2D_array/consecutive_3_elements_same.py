


arr = [['a','a','a','b','c'],['a','a','e','l','c'],['b','a','e','m','c'],['c','a','e','e','e'],['d','a','d','d','d']]

print arr

m = max([len(l) for l in arr])

print "column: ", m

n = len(arr)

print "row: ", n

count = 0

for i in range(m):
	print "i: ", i
	for j in range(n):
#		print "j: ", j
#		print "===>Element:", arr[j][i]
		k = j
#		print "k", k
		if k+2 < n:
			print arr[k][i] , arr[k+1][i] , arr[k+2][i]
			if arr[k][i] == arr[k+1][i] == arr[k+2][i]:
				print "Consecutive 3 vertical same Elements found"
				count = count + 1

print "Verical consecutive 3 elements same: Count is ", count

h_count = 0

for i in range(m):
	for j in range(n):
		k = j
		if k+2 < n:
			if arr[i][k] == arr[i][k+1] == arr[i][k+2]:
				print  "Consecutive 3 horizontal same Elements found"
				h_count += 1



arr1 = [['a','a','a','b','c'],['a','e','e','l','c'],['b','a','e','m','c'],['c','a','e','e','e'],['d','a','d','d','e']]





print "Horizontal consecutive 3 elements same: Count is ", h_count

d_count = 0

for j in range(m):
	i = j
	if j+2 < m:
		if arr1[i][j] == arr1[i+1][j+1] == arr1[i+2][j+2]:
			print "Dia same elements found"
			d_count += 1

print d_count
