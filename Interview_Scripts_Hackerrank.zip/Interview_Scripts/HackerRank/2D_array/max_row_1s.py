arr = [[1,0,0,1,0,1],
       [1,1,1,0,0,1],
       [1,1,0,0,0,1],
       [1,1,1,1,1,1],
       [1,1,1,1,1,0]]


count = 0
max = 0

for i in range(5):
	for j in range(6):
		if arr[i][j] == 1:
			count += 1
	if count > max:
		max = count
		print "Max: ", max
		row_num = i
	count = 0

print ("Row Number is: {0} and 1s count is: {1}".format(row_num,max))





