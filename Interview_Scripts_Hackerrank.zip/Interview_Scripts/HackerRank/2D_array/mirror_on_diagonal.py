"""
Given a Input Matrix of NXN . Print the matrix after mirroring on its primary diagonal 
if Input is 1,2,3,4,5.6,7,8,9 
Output is 1,4,7,2,5,8,3,6,9
"""
import numpy as np

def mirror_matrix(arr):

	rows = len(arr)
	columns = len(arr[0])

	print "row: ", rows
	print "columns: ", columns

	print "Original Matrix: "

	print (np.matrix(arr))

	for i in range(rows):
		for j in range(columns):
			if i < j:
				arr[i][j], arr[j][i] = arr[j][i] , arr[i][j]

	
	print ("New Matrix: ")

	print ( np.matrix(arr))



arr = [[1,2,3,4],
       [5,6,7,8],
       [9,10,11,12],
       [13,14,15,16]]


mirror_matrix(arr)
