import numpy as np


def matrix_zero(A, rows, columns):

	print ("Rows: ", rows)
	print ("Columns: ", columns)

#	rows = 6
#	columns = 5
	row = [0]* rows
	column = [0] * columns
	print (row, column)

	for i in range(rows):
		for j in range(columns):
			print ("matrix[{0}][{1}]:  {2}".format(i,j,A[i][j]))
			if A[i][j] == 0:
				row[i] = 1
				column[j] = 1

	for i in range(rows):
        	for j in range(columns):
			if row[i] == 1 or column[j] == 1:
				A[i][j] = 0


	for i in range(rows):
		for j in range(columns):
			print (A[i][j])
		print ("\n")	

	print np.matrix(A)


arr =   [[1,1,1,1,1]		,
	 [1,1,1,1,1],
	 [1,1,0,1,1],
	 [1,1,1,0,1],
	 [1,1,1,1,1],
	 [1,1,1,1,1]];

arr1 = [[1,1,1,1],
	[1,0,1,1],
	[0,1,1,1],
	[1,1,1,1]];

matrix_zero(arr1,4,4)


