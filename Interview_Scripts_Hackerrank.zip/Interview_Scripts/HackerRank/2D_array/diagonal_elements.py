arr = [['a','a','a','b','c'],['a','a','e','l','c'],['b','a','e','m','c'],['c','a','e','g','e'],['d','a','d','d','d']]

for i in range(5):
	j = i
	print arr[i][j]
	
for i in range(5):
        j = i+1
	if j < 5:
        	print arr[i][j]

for i in range(5):
        j = i+2
        if j < 5:
                print arr[i][j]
 
k = 0
l = 0

for k in range(3):
	
	for i in range(5):
		j=i+k
	
		if j < 5:
			print arr[i][j]
		print "Diagonal change: "
		

	
