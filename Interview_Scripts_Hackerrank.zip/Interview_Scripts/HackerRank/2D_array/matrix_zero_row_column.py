import numpy as np

def row_column_zero(arr):

	print "Original Matrix: "

	print np.matrix(arr)
	
	rows = len(arr)
	columns = len(arr[0])

	print "Rows: ", rows, "Columns: ", columns

	row_list = []
	column_list = []

	for i in range(rows):
		row_list.append(0) 
	for i in range(columns):
		column_list.append(0)

	print "Row_list: ", row_list
	print "Column List: ", column_list


	for i in range(rows):
		for j in range(columns):
			if arr[i][j] == 0:
				row_list[i] = 1
				column_list[j] = 1

	print "Row_list: ", row_list
        print "Column List: ", column_list


	for i in range(rows):
		for j in range(columns):
			if row_list[i] == 1 or column_list[j] == 1:
				arr[i][j] = 0


	
	print np.matrix(arr)



arr =   [[1,1,1,1,1],
         [0,1,1,1,1],
         [1,1,1,1,1],
         [1,1,1,1,0]]

row_column_zero(arr)

