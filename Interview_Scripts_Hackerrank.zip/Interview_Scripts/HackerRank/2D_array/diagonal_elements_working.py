
#arr = [['a','a','a','b','c'],['a','a','e','l','c'],['b','a','e','m','c'],['c','a','e','g','e'],['d','a','d','d','d']]


arr = [['e','m','l','b','c'],
       ['a','e','m','l','c'],
       ['b','a','e','m','l'],
       ['c','a','e','g','m'],
       ['d','a','d','d','d']]


count = 0

##  gap between i and j is increasing with each diagonal from 0 to 4 
##  for that gap we take outer loop k which increments by 1 every time
##  (00,11,22,33,44) (01,12,23,34) (02,13,24) (03,14) (04)

for k in range(5):
        for i in range(5):
                j=i+k
                if j+2 < 5:
			print arr[i][j] , arr[i+1][j+1] , arr[i+2][j+2]
                       	if arr[i][j] == arr[i+1][j+1] == arr[i+2][j+2]:
				print "Consecutive elements found"
				count += 1		
        print "Diagonal change: "


print "Count of same elements: ", count
