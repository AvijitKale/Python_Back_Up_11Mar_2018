def spiral(arr,m,n):

	k = 0
	print m,n

	while(k<m):
		for i in range(n):
			print arr[k][i]
		k += 1

		for i in range(n-1,-1,-1):
			print arr[k][i]
		k += 1


arr =   [[1,2,3,4,5],
        [6,7,8,9,10],
         [11,12,13,14,15],
         [16,17,18,19,20],
         [21,22,23,24,25],
         [26,27,28,29,30]];


spiral(arr,6,5)
