

arr = [ [1,0,0,1,1],[0,1,1,0,1],[1,0,1,0,1]]

m = max([len(l) for l in arr])

print "column: ", m

n = len(arr)
print "row: ", n


