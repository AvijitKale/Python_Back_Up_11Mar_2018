def fizzbuzz(start,end):
	for i in range(start,end,1):
		entry = ""
		if i%3 == 0:
			entry += "FIZZ"
		if i%5 == 0:
			entry += "BUZZ"
		if i%3 != 0 and i%5!= 0:
			entry = i
		print entry
	
fizzbuzz(3,20)
