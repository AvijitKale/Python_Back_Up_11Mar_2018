num = input("Enter the number: ")

print num

sum = 0

while num  > 9:
	sum = sum + (num % 10)

	print ("sum :{0}".format(sum))

	q = num /10

	num = q

	print ("Q:{0} ".format(q))
	if q < 10:
		num = sum + q
		if num < 10:
			sum = num
		else:
			sum = 0
	print ("num:{0} ".format(num))

print ("Final single Digit sum of the given num: {0}".format(sum))	
