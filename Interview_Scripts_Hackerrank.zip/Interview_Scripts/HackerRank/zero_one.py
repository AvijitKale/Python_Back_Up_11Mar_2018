def fun(seq):
	list1 = seq
	count = i = m = 0
	
	while i < len(list1):
		if list1[i] == 1 and list1[i+1] == 1 and list1[i-1] == 1:
			m = i
		print "Starting with i from: ", m
		if list1[i] == 0 and (i+1) != len(list1):
			
			if list1[i+1] == 1:
				print "Swap Needed:  ", list1[i], list1[i+1]
				list1 = swap(list1,i,i+1)
				count += 1
				if list1[i-1] == 0:
					list1 = swap(list1,i-1,i)
					count  += 1
				i = m
				print "\t\tCount: ", count
		print list1
		i = i+1				
	print "\n\nList: ", list1		
	print "Count:  ", count


def swap(list,n,k):
	temp =list[k]
	list[k] = list[n]
	list[n] = temp 
	return list


if __name__ == '__main__':
	seq = [1,1,0,1,1,0,0,0,1,0,1,0,1,0,1,0]
#	seq = [1,1,0,0,0,0,0,0,0,1]
	fun(seq)
