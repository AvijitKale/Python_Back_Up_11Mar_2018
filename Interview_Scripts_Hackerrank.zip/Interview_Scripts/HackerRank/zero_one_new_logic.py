def zero_one(alist):

	i = count  = m = 0
	flag = None

	while i < len(alist):
		print "i: ", i , "alist[i]" , alist[i]
		while alist[i] == 1:
			i += 1

		if alist[i] == 0 and count == 0:
			count = i 
			m = count	
	
		while alist[i] != 1 and i > count:
			i += 1
		
		if alist[i] == 1 and i > count:
			alist[count], alist[i] = alist[i], alist[count]	
			count = 0
		
		i = m

	print alist
		

alist = [1,1,0,0,0,1,1,0,0,0,1]

zero_one(alist)
		
