## This Program will find pivot value : 
## Pivot value = sum of numbers on left == sum of numbers on right

arr = [1,4,5,12,6,8,9,7,8,3,9,2,8,7,8]
L_sum = R_sum = 0
k = 0

for i in range(len(arr)):

	print "{0} : {1} ".format(i,arr[i])	
	for k in range(i-1,-1,-1):
		print "arr element {0}: {1}".format(k,arr[k])
		L_sum = L_sum + arr[k]
	print ("L_sum:{0}".format(L_sum))

	for j in range(i+1, len(arr)):
		R_sum = R_sum + arr[j]
	print ("R_sum:{0}".format(R_sum))


	if L_sum == R_sum:
		print "Pivot value of an array: {0}".format(arr[i])
		L_sum = R_sum = 0

	else:
		L_sum = R_sum = 0



