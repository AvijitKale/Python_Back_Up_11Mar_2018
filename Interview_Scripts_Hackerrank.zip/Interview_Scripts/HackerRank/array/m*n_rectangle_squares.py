def square(m,n):
	
	global square_count

	x = min(m,n)
	y = max(m,n)

	z = y-x

	print "square formed: ", x , "by" , x

	square_count += 1

	if z > 0:

		print "Passing values: ", z,x
		square(z,x)


	print "square Count: ", square_count
	
			
global square_count 
square_count = 0

square(15,4)
