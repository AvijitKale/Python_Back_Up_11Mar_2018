## This program will check if sum of any 2 elements in array is present in array itself

arr = [1,2,3,4,5,6,7,8,9,12,14,15,18,19]

for i in range(0,len(arr),1):
	for j in range(1,len(arr),1):
		sum = arr[i] + arr[j]

		for k in range(len(arr)):
			if arr[k] == sum:
				print "Sum Found of numbers: {0} + {1} = {2}".format(arr[i], arr[j] , sum)
		
