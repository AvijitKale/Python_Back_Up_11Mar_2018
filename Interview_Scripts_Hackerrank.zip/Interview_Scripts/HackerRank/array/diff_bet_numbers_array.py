"""Given  integers, count the number of pairs of integers whose difference is k """

def diff_integer(arr):

	l = len(arr)

	k = 2
	i = count = 0
	numbers = []

	while i < l:                     #### We can use abs(arr[i]-arr[j])  instead of finding min and max

		for j in range(i+1,l,1):
			m = max(arr[i], arr[j])
			n = min(arr[i], arr[j])

			if (m-n == k):
				numbers.append([arr[i],arr[j]])
				count += 1
		i += 1

	print "Total number of Pairs: ", count
	print "Pairs: ", numbers


arr = [1,5,3,2,4,6]

diff_integer(arr)

