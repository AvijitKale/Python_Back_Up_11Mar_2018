"""
https://www.hackerrank.com/challenges/maximum-subarray-sum
"""
def max_suarray_modulo(arr,modulo_x):

	ln = len(arr)
	x = modulo_x	

	i = 0
	mod_arr = ar1 = []
	
	max_mod = 0

	while i < ln:
		m = 0
		
		while m+i < ln:
			ar1 = []
			j = m
			ar1.append(arr[j])
			for k in range(i):
				ar1.append(arr[j+1])
			print "subarray: ", ar1

			mod = sum(ar1)%x
			mod_arr.append([ar1,sum(ar1),mod])
			if mod > max_mod:
				max_mod = mod 	
			
			m += 1
		i += 1
		
	print "Modulo array: ", mod_arr

	print "maximum modulo :", max_mod


arr = [3,3,9,9,5]
modulo_x = 7

max_suarray_modulo(arr,modulo_x)
			
