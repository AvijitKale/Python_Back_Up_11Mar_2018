arr = [3,5,9,12,1,17,18,2,4,6]


max_diff = 0

for i in range(len(arr)):
	for j in range(i+1, len(arr)):

		if (arr[j] - arr[i]) > max_diff:
			max_diff = arr[j] - arr[i]

		
print max_diff




