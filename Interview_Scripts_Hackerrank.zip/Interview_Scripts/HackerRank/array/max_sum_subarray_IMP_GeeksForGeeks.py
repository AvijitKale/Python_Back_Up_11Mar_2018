def maxSubArraySum(a):
     
    max_so_far = 0
    max_ending_here = 0
     
    for i in range(len(a)):
        max_ending_here = max_ending_here + a[i]
        if max_ending_here < 0:
            max_ending_here = 0
         
        # Do not compare for all elements. Compare only   
        # when  max_ending_here > 0

        elif (max_so_far < max_ending_here):
            max_so_far = max_ending_here

	print "max_so_far : ", max_so_far

        print "max_ending_here: ", max_ending_here

             
    print "Max Sum of subarray: ", max_so_far



alist = [-2, -3, 4, -1, -2, 1, 5, -3]

maxSubArraySum(alist)
