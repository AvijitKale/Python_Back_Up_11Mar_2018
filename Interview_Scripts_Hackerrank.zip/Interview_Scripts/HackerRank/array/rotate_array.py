def rotate(arr,n):
	num = 0

	
	while num<n:
		last = arr[len(arr)-1]
		print "Last: ", last , "arr: ", arr
		arr = arr[0:len(arr)-1]
		print "except last arr:", arr
		arr.insert(0,last)
		print "arr after rotation {0} times: {1} ".format(num+1, arr) 
		num += 1
		print "\n"

	print arr

arr = [1,2,3,4,5,6,7,8]

rotate(arr,4)

		
		
	
