def equal_sum(arr):
	length = len(arr)
	
	i = 0
	while i < length:
		leftSum = rightSum = 0
		print "i: ", arr[i]
		for j in range(0,i,1):
			leftSum += arr[j]

		for k in range(i+1,length,1):
			rightSum += arr[k]

		if leftSum == rightSum:
			print "LeftSum and RightSum are Equal i.e. {0} for element {1} ".format(leftSum, arr[i])

		i += 1

		
arr = [2,1,6,5,9,3,7,6,2,8]

equal_sum(arr)

