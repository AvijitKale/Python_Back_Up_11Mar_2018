"""
Given input as an integer array and an integer 'k', find and print element with maximum value from each sub-array of size 'k'.
For example, for the input array {4,2,12,34,23,35,44,55} and for k = 3, output should be 12,34,34,35,44,55. 
"""

def max_element(alist,k):
	
	result = []

	ln = len(alist)

	for i in range(ln):
		max = alist[i]
		if i+k <= ln:
			for j in range(i,(i+k)):
				if alist[j] > max:
					max = alist[j]

			result.append(max)

	print result


alist = [4,2,12,34,23,35,44,55]

k = 3

max_element(alist,k)

		
			
		

