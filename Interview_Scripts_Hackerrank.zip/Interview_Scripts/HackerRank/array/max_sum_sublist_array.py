def max_sum(arr):


	ln = len(arr)

	sum = 0

	for i in range(ln):
		sum += arr[i]

	max = sum

	new_list = []

	sub_sum = 0
	
	max = arr[0]

	index_list = []

	dict = {}

	for i in range(ln):
		if arr[i] > 0:
			index_list.append(i)
			sub_sum = sub_sum + arr[i]
			if sub_sum > max:
				max = sub_sum
				print "Index List: ", index_list				
				print "Max: ", max	
		else:
#			print "ELse: "
#			print "index list in else: ", index_list
#			print "max in else: ", max
			if max not in dict.keys():
				dict[max] = index_list	
			print "dict: ", dict
			sub_sum = 0
			index_list = []

	print "Max_sum : ", max
	print "new_list: ", dict

		
		
							
alist = [-1,3,6,-5,-10,8,8,-3,6,12,-4]				
max_sum(alist)
				
