def increasing_seq(arr):

	result = []
	i = 0

	while i < len(arr):
		j = i + 1
		if j == len(arr):
			break
		print ("i: ", i , "j: ", j, "Numbers to compare: ", arr[i] , arr[j])
		new_arr = []
		new_arr.append(arr[i])
		while j < len(arr):
			if arr[j] > arr[i]:
				new_arr.append(arr[j])	
				i = j
				j += 1	
			else:
				i = j
				result.append(new_arr)
				break
		
	print result


arr = [12, 45, 65, 18, 7,13,27,31,40, 5,10,34,23]

increasing_seq(arr)
