arr = [[1,1,1],[0,1,1],[1,1,1],[1,1,1],[1,1,1]]



m = len(arr)

print "Number of columns:{0}".format(m)

n = len(arr[0])

print "number of rows:{0}".format(n)

x = y = 0

for i in range(x,m,1):
	for j in range(y,n,1):
		if arr[i][j] == 0:
			for k in range(m):
				arr[k][j] = 0
			for p in range(n):
				arr[i][p] = 0
			x = k+1
			y = p+1
		else:
			pass

print arr




