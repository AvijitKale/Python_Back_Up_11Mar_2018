def pattern(num):

	for i in range(num-1,0,-1):
		print " ",
	
		for j in range(i ,num):
			print "#"



if __name__ == '__main__':
	pattern(6)



