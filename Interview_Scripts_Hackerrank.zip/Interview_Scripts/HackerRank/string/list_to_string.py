l1 = [1,2,3,4,5,6]

str1 = "abcdefghi"

l2 = list(str1)

print l2

print l1

l3 = [str(x) for x in l1]

print l3


str2 = ''.join(l3)

print str2
