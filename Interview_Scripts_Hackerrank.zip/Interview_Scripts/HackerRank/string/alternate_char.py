"""
You are given a string containing characters  and  only, your task is to change it into a string such that every two consecutive characters are different. To do this, you are allowed to delete the one or more characters in the string.
Your task is to find the minimum number of required deletions.
For example, string  should be changed to  by deleting one character .
AAAA  A, 3 deletions
BBBBB  B, 4 deletions
ABABABAB  ABABABAB, 0 deletions
BABABA  BABABA, 0 deletions
AAABBB  AB, 4 deletions because to convert it to AB we need to delete 2 A's and 2 B's
"""

def alternate(string):

	length = len(string)

	i = count = 0

	new_string = ""

	flagA = flagB = True

	while i < length:

		if string[i] == 'A' and flagA :
			flagA = False
			flagB = True
		elif string[i]  == 'B' and flagB :
			flagB = False
			flagA = True
		else:
			string.translate(None, string[i]) ## can use this as well ==> string.replace(string[i], "") 
			count += 1
		i += 1

	print "Total number of deletions required:{0}".format(count)

string = "AAAAAABBBBBB"
alternate(string)

			 	
