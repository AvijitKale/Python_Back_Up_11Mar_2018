class Solution:
    # @param A : string
    # @param B : string
    # @return a strings
    def multiply(self, A, B):
        
        A = int(A)
        B = int(B)

        C = A*B
        
        result = str(C)
        
        return result

s = Solution()

print (s.multiply("10", "23"))


