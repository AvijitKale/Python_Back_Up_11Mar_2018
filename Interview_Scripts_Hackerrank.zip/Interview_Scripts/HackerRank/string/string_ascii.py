astring = raw_input("Enter the string: ")

print astring

ascii_list = [ord(c) for c in list(astring)]

print ascii_list

sorted_list = sorted(ascii_list)

str = ""

for i in sorted_list:
	str = str + chr(i)
	
print str
