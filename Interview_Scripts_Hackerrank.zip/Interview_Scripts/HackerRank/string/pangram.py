def pangram(string):

	string1 = "abcdefghijklmnopqrstuvwxyz"

	string = string.lower()
	flag = True
	
	for x in string1:
		if x not in string:
			print "Not present: ", x
			flag = False
	if flag:
		print "Every character is present"
		

string = "promptly udged antique buckles for the next prize"

pangram(string)
