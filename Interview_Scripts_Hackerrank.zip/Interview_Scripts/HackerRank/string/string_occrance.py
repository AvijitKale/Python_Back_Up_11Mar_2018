string = "aaaaaabbbbbbbbbbbbccccdddddddefggggggghijk"

count = len(string)

output = ""

i = 0

while i < count:
	k = 0
	for j in range(i+1,count,1):
		if string[i] == string[j]:
			k += 1
		else:
			print "Breaking: "
			break
	
	output = output + string[i]
	
	if k > 1:
		output = output + str(k+1)
		i = i + k + 1

	else:
		i += 1


print output
	
		

	
