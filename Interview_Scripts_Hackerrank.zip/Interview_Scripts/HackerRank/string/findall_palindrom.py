def findall_palindrom(string):

	ln = len(string)

	counter = 0
	OneTimeFlag = True

	for i in range(ln):
		for j in range(i+1,ln,1):
			if string[i] == string[j]:
				new_str = ""
				temp_len = (j-i) +1
				print "Length of new_string: ", temp_len
				for l in range(i,i+temp_len,1):
					new_str = new_str + string[l]				
				print new_str

				if temp_len > 2:
					j = i
					k = i+temp_len-1
					print "j:{0} and k:{1}".format(j,k)
				
					if OneTimeFlag or (k > ol_k) :
						flag = False
						original_k = k
						OneTimeFlag = False
						x = 0
						while x!=temp_len/2 and j < ln and k < ln:
							print "j:{0} and k:{1}".format(j,k)
							if string[j] == string[k]:
								flag = True
							else:
								flag = False	
								break
							j+=1
							k-=1
							x+=1
						if flag == True:
							print "\n**** Palindrome string: ", new_str
							counter += 1
							ol_k = original_k
					else:
						print "Palindrome within the old Palindrome"

	print "Total number of palindrom strings: ", counter

string = "abcdcmcdpqqpdhlzlhstrtsh"

findall_palindrom(string)

		
		
