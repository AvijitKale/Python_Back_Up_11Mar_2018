string = "abcdefg"


n = len(string)

str1 = ""
new_str = []

i = 1
while i < n:
	m = 0
        str1 = ""	
	while m+i < n:
		j = m
		str1 = str1 + string[j]
		for k in range(i):
			str1 = str1 + string[j+1]
			j += 1
		str1 = str1 + "/"
			
		m += 1
	new_str.append(str1)
		
	i += 1

print new_str
