"""
n = length of string
k = number given (n has to be divisible by k)
split the string into n/k parts and each part has to have unique characters
"""


def merge_the_tools(string, k):
    # your code goes here
    str_len = len(string)
    n = str_len/k
    alist = []
    
    print "n: ", n 

    m = 0

    for j in range(n):
        str = ""
        for i in range(m,k+m,1):
            if string[i] not in str:
                str = str + string[i]
	    else:
		pass
        print (str)
	m += k

string = "AABCAAADAECC"
k = 3

merge_the_tools(string,k)
