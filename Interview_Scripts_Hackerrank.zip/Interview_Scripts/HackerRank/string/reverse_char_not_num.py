"""
Write a function accepting a string with numbers and letters that reverses the letters of the string but leave numbers in the same position. 

Example input: str1ngw1thnumb3rs 
Example output: srb1mun1htwgnr3ts

"""

def reverse_char_not_digits(string):
#	output = "srb1mun1htwgnr3ts"

	count = len(string)

	arr = []

	digit_arr = []

	for i in range(count):
		print "string char: ", string[i]
		if string[i].isdigit():
			print "Digit: ", string[i]
			arr.append(i)
			digit_arr.append(string[i])
	print "Digit Indices Array: ", arr

	print "Digit Array: ", digit_arr
	
	str1 = ""

	for i in range(len(string)-1, -1,-1):
		print "char: ", string[i]
		if string[i].isdigit():
			i += 1
		else:
			str1 = str1 + string[i]
		print "str: ", str1


	print "reverse char string: ", str1

	lst = list(str1)
	
	print "List: ", lst

	for j in range(len(arr)):
		print "Loc: , Digit: ", arr[j] , digit_arr[j]
		lst.insert(arr[j],digit_arr[j])


	str2 = "".join(lst)


	print "Final String: ", str2


	if str2 == output:
		print "Correct Output"

#string = "str1ngw1thnumb3rs"

string = "avij2it5k1al9e7"

#output = "srb1mun1htwgnr3ts"

output = "elak2ti5j1iv9a7"

reverse_char_not_digits(string)



	
			
