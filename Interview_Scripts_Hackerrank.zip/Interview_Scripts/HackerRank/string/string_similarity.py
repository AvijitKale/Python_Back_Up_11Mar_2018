"""
Input: ababaa
The suffixes of the string are "ababaa", "babaa", "abaa", "baa", "aa" and "a". The similarities of these strings with the string "ababaa" are 6,0,3,0,1, & 1 respectively. Thus, the answer is 6 + 0 + 3 + 0 + 1 + 1 = 11.
"""

def string_simi(str1,str2):

	n = len(str2)

	i = 0

	count = 0

	for j in range(n):
		
		if str1[i]== str2[j]:
			i += 1
			count += 1
		else:
			break

	print "Count ", count


str1 = "ababaa"

ln = len(str1)

for i in range(ln):
	str2 = str1[i:]
	string_simi(str1, str2)




