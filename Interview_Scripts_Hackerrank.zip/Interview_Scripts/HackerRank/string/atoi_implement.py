# Python program for implementation of atoi
 
# A simple atoi() function
def myAtoi(string):
    res = 0
    # initialize sign as positive
    sign = 1
    i = 0
 
    # if number is negative then update sign
    if string[0] == '-':
        sign = -1
        i+=1

    ### ord is the function which prints character's  ASCII value   ord('0') = 48  ord('A') = 65
 
    # Iterate through all characters of input string and update result
    for j in xrange(i,len(string)):
        res = res*10 + (ord(string[j]) - ord('0'))
	print "Res: ", res
 
    return sign*res
 
# Driver program
string = "-123"
print myAtoi(string)
