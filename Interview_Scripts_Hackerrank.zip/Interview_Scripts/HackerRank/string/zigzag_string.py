def zigzag_print(string , num_of_rows):

	n = int(num_of_rows)

	count = len(string)

	diff = n + (n-2)

	fixed_diff = diff

	arr = []
	for j in range(n-1):
		arr.append(diff)
		diff = diff - 2
 	
	arr.append(fixed_diff)

	print "List of Arr: ", arr
	
	new_row = " "


	for i in range(n):
		j = i
		print "J: ", j
		row = " "
		row  = row + string[i]
		while i < count:
			print "i: ", i
			print "char: ", string[i]
			print "arr[j]: ", arr[j]
			i = i + arr[j]
			if i < count:
				row  = row + string[i]
			print "i after increment: ", i	
			if j != 0  and j != (n-1):
				print "Inside Loop: "
				i = i + (j*2)
				if i < count:
					row = row + string[i]	
		print "Row: ", row		
				
		new_row = new_row + row				
		
	print "\n\n Complete List of rows in sequential manner, after printing string in zigzag manner: \n", new_row


string = "abcdefghijklmnopqrstuvwxyz"

n = raw_input("Enter the number of rows for the string: ")

zigzag_print(string, n)
	

		
	
