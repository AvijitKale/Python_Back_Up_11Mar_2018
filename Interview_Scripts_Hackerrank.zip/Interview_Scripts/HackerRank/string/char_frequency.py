def char_freq(astring):

	i=count = 0

	o_string = ""

	while i < len(astring):
		count = 0
		for j in range(i+1, len(astring), 1):
			if astring[i] == astring[j]:
				count += 1

		if count > 0:
			o_string = o_string + astring[i] + str(count)
	
		else:
			o_string = o_string + astring[i]
	
		if count > 0:
			i = i + count + 1

		else:
			i += 1

	print o_string



astring = 'aaaaabbbbbbccccdddddefg'

char_freq(astring)

