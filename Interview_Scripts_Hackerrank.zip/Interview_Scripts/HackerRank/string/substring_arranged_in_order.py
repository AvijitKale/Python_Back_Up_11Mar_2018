"""
Arrange all the distinct substrings of given string in "lexicographical" order i.e.(from a - z) and concatenate them. 
Input: dbac
Output: a, ac, b, ba, bac, c, d, db, dba, dbac  and then concatenate them to form a single string
"""

def ordered_substring(string):

	str1 = "abcdefghijklmnopqrstuvwxyz"

	ln = len(string)

	i = 0
	main_str = ""
	while i < 26:
		for j in range(len(string)):
			if str1[i] == string[j]:
				print "char: {0} , Location: {1}".format(str1[i], j)

				p = 0
				str2 = ""
				while p < (len(string) - j):
					m = j
					if m + p < len(string):
						str3 = ""
						str3 = str3 + string[m]
						print "First: ", str3
						for k in range(1,p+1):
							str3 = str3 + string[m+k]
							print "After adding {0}: {1}".format(k,str3)
					str2 = str2 + str3	
					p += 1
						
				main_str = main_str + str2
		i += 1

	print "Main String formed: ", main_str


string = "pngkac"

ordered_substring(string)

			
				
						   

	

		
