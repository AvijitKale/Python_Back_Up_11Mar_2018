def build_string(string):

	b_string = ""

	count = len(string)

	i = 0

	while i < count:
	
		add(string[0])
		
		if len(b_string > 1):
			for j < len(b_string):
				
				append(substr)	

	

	def add(b_string,char):
		b_string = b_string + char
	
	def append(b_string, substr):
		b_string.append(substr)
