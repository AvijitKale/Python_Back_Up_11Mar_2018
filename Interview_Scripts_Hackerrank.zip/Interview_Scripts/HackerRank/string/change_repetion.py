def replace(string):

	count = len(string)

	i = m = k = 0

	str1 = ""

	while i < count:
		
		try:
			n = string.index("010", m)
			print "Occurance at : ", n
			if n >= 0:
				lst = list(string)

				lst[n+2] = "1"
				print "List: ",lst				

				str1 = "".join(lst)
					
				print "String: ",str1
				string = str1
				m = n+3
				i = m
				k += 1
		except:	
#			print "No string found "	
			i += 1
			m = i
	
	print "Total number of changed made: ", k

string = "0101010101001011010"

print "Original String: ", string

replace(string)		
