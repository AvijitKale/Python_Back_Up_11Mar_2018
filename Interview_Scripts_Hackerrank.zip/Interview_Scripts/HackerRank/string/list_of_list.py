def list_of_list(alist):

	l = len(alist)
	repeated_count = 0
	r_flag = False
	r_list = ro_list = []

	for i in range(len(alist)):
		for j in range(len(alist[i])):
			for m in range(j+1, len(alist[i]), 1):
				if alist[i][j] == alist[i][m]:
					print "Same Element of same list: ", alist[i][j], "and " , alist[i][m]
					if alist[i][j] not in r_list:
						print "I am in Same Loop"
						repeated_count += 1
						r_flag = True
						print "R_list in same loop: ", r_list
				print "Repeated Count: ", repeated_count
				print "R_list: ", r_list

			for k in range(i+1, len(alist), 1):
				for n in range(len(alist[k])):
					if alist[i][j] == alist[k][n] :
						print "Same Element of other list : ", alist[i][j] ,"and" ,alist[k][n]
						if alist[i][j] not in r_list:
							print "I am in other Loop "
							repeated_count += 1
							r_flag = True
				print "Repeated Count: ", repeated_count
			if r_flag:
				print "I am in R_list Loop"
				r_list.append(alist[i][j])
				r_flag = False

	sum = 0

	for i in range(len(alist)):
		sum = sum + len(alist[i])


	print "Total Strings processed : ", sum	

	print "Repeated Strings count: ", repeated_count
	print "Repeated String: ", r_list
	print "Unique Strings: ", sum - repeated_count
	


alist = [['g','gh','ghj','g'],['j','ju','gh','gk','gn','g'],['ju','jl','th','gk','ju','jl']]

list_of_list(alist)
			
							
			
