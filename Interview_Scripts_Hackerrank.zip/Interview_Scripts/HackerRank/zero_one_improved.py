def fun(seq):
	list1 = seq
	count = i = k =  0
	
	while i < len(list1):
		while list1[i] == 1:
			print "Found 1: "
			i += 1		
		m = i
		print "Starting from : ", i
		while list1[i] == 0 and (i+1) < len(list1):
			if list1[i+1] == 1:
				list1[i],list1[i+1] = list1[i+1],list1[i]
				count += 1
#				i -= 1
			else:
				i += 1
			
			if i+1 >= len(list1):
				break						
		if i+1 >= len(list1):
			break

		print "List1 after each iteration: ", list1
		i = m
	print "Number of changes needed  :", count
	print "Final List: ", list1

if __name__ == '__main__':
	seq = [1,1,0,1,1,0,0,0,1,0,1,0,1,0,1,0]
#	seq = [1,1,0,0,0,0,0,0,0,1]
	fun(seq)
