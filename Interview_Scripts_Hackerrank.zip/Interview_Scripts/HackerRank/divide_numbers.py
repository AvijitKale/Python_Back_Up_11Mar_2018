def divide_num(a,b):
	count = 0
	sign = 0
	if a > 0:
		a = a
		sign  = 1
	elif a < 0:
		a = a * (-1)
		sign = -1
	while a > 0:
		a = a - b
		if a < 0:
			break
		count += 1
	result = count * sign

	return result

division = divide_num(-47,3)

print division
