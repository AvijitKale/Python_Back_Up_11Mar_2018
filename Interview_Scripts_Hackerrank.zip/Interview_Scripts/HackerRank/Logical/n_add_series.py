from __future__ import division

def add_series(n):

	sum = 0

	for x in range(1,n+1):
		y = x + 1
		sum = sum + x/y
		print sum		

	print "Final Sum: ", sum


add_series(6)
