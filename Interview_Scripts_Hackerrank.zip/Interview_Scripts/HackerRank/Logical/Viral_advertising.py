"""
On the first day, half of those  people (i.e., ) like the advertisement and each person shares it with  of their friends; the remaining people (i.e., ) delete the advertisement because it doesn't interest them. So, at the beginning of the second day,  people receive the advertisement.
Input: A single integer, , denoting a number of days.
Output: Print the number of people who liked the advertisement during the first  day.
"""

def people_liked():
	

