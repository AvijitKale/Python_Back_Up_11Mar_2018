"""
Davis has  staircases in his house and he likes to climb each staircase , , or  steps at a time. Being a very precocious child, he wonders how many ways there are to reach the top of the staircase.

# recursion requirement: it returns the number of way up
# a staircase of n steps, given that the number of steps
# can be 1, 2, 3

output:

stairs_ways(0) => 1
stairs_ways(1) => 1
stairs_ways(2) => 2
stairs_ways(3) => 4
stairs_ways(4) => 7
stairs_ways(5) => 13
stairs_ways(6) => 24
stairs_ways(7) => 44
stairs_ways(8) => 81

"""

def fib(n):
	if n == 1:
		return 1
	elif n < 1:
		return 0
	else:
		return fib(n-1) + fib(n-2) + fib(n-3)


def stairs_ways(s):
	return fib(s+1)


if __name__ == '__main__':
	
	s = input("Enter the number of stairs in a stair case: ")

	ways = stairs_ways(s)

	print "Number of ways to climb staircase are: {0}".format(ways)
