''' Dequeue the element with least priority (lowest value of the key-value pair) from the list 
    Enqueue any element to the list.. as a key-value pair  Elements will be in random order inside the list	
'''


jobs = [ 
	('A', 2),
	('B', 4),
	('C', 5),
	('D', 1),
	('E', 3)
       ]


def enqueue(a):
	jobs.append(a)


def dequeue():
	dict = {}
	for x in jobs:
		dict[x[0]] = x[1]

	for k,v in dict.items():
		print k, "=>" , v

	d_sorted = sorted((v,k) for (k,v) in dict.items())

	print "Sorted dict: ", d_sorted

	print "Dequeued Element: ", d_sorted[0]

	alist = []

#    Removing dequeued Element from jobs list.

	for x in jobs:
		if x[0] == d_sorted[0][1]:
			jobs.remove(x)

	print jobs


enqueue(('F', 7))

enqueue(('G', 6))

print jobs

dequeue()

enqueue(('H', 10))

enqueue(('I', 13))

dequeue()

enqueue(('J', 12))

dequeue()

enqueue(('K', 11))
	


	
