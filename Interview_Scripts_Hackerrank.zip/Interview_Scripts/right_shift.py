def RightShift(astring,n):
    count = len(astring)
    for i in range(n):
        temp = astring[0]
	new_string = astring[1:count] + temp
	astring = new_string
    return astring


def LeftShift(astring, n):
    count = len(astring)
    for i in range(n):
	temp = astring[-1]
	new_string = temp + astring[0:count-1]
	astring = new_string
    return astring

astring = raw_input("Enter the string: ")

right_num = input("Enter the right shift number:")

left_num = input("Enter the left shift number:")

right_string = RightShift(astring,right_num)

left_string = LeftShift(astring, left_num)

print "String after %s right shift is %s"  %(right_num ,right_string)

print "String after %s left shift is %s" %(left_num, left_string)



    
