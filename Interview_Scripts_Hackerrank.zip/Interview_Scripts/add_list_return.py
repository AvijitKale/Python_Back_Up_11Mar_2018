
alist = []
blist = []

for i in range(10):
	
	if i % 2 == 0:
		alist.append(i)

	else:
		blist.append(i)


print alist

print blist

print alist + blist


