from pythonds.basic.stack import Stack

def reverse(sen):
	s= Stack()
	count = len(sen)
	print count
	w_str = ""
	for c in sen:
		s.push(c)	
		
	while s.size():
		w_str += s.pop()
	return w_str

print reverse("sentense")



