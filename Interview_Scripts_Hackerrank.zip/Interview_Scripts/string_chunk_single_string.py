#### This program finds all the duplicate strings in a single string::  Max number of duplicates count has to be 1


str1 = "ghiabcdfcxbabclfcxbkghi"

list1 = []
str2 = ""
str3 = ""
m = 0
for y in range(m ,len(str1),1):
	x = y + 1
	str2 = str3 = ""
	while x < len(str1):
#		print "X: and length", x , len(str1)
		if str1[y] == str1[x] and x <= len(str1):
			str2 = str2 + str1[x]
                	y = y + 1
			flag = True
			if x == (len(str1)-1) and len(str2) > 2 and flag:
                                list1.append(str2)
                                flag = False
                                m = y

		elif str1[y] != str1[x] and  x <= len(str1):
			if len(str2) > 2 and flag:
                                list1.append(str2)
				flag = False
				m = y
				print "==========>str1[X] after one list: ", str1[x]
			str2 = ""
			print "m: ", m
		elif x > (len(str1)):
                        y = m
                        break
		x = x + 1
	
print list1
			
			


