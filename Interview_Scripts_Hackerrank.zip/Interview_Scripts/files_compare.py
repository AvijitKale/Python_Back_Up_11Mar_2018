def file_compare(a,b,pos):
	a = in_file_a
	b = in_file_b

	flag = True

	ca = in_file_a.read(pos)
        cb = in_file_b.read(pos)

	print "First File:", ca
        print "Second FIle: ", cb


	while (ca != '' or cb != ''):
		ca = in_file_a.read(pos)
		cb = in_file_b.read(pos)

		print "First File:", ca
		print "Second FIle: ", cb

		if ca != cb:
			flag = False

		pos = pos + 1
	
	if flag:
		print "File are equal"
	


if __name__ == '__main__':
	in_file_a = open("filename_a", "r")
	in_file_b = open("filename_b", "r")

	file_compare(in_file_a, in_file_b,0)

	in_file_a.seek(0,0)
	pos = in_file_a.tell()
	
	print "Position: ", pos	
	


