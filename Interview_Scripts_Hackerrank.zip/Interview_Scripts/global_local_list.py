def fun(l = None):
	print "Inside: {0}".format(l)
	l.append(10)
	print "Inside Function after appending value: {0}".format(l)


if __name__ == '__main__':
	l = [1,2,3,4]
	print "Global :{0}".format(l)
	fun(l)
	print "After executing function: {0}".format(l)
