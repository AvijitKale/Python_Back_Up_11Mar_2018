def f(n):
	for i in range(n):
    		yield i

def g():
    return


for item in f(5):
	print item


print 'g()=', g()
