alist = [1,2,4,5,6,7]

print len(alist)

print alist

alist.append(8) 


print alist

atuple = tuple(alist)

print atuple

alist[0] = 10


## CAN not change tuple values:  ERROR at this 

atuple[0] = 100

print alist

print atuple
