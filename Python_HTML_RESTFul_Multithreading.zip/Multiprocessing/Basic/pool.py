from  multiprocessing import Pool

def f(x):
	return x*x*x

def main():
	p = Pool(processes = 6)
	print "=>", p
	print (p.map(f,[1,2,3,4,5,6]))
	print (p.map(f,range(10,15,1)))

if __name__ == '__main__':
	main()
