from multiprocessing import Process , Lock

def fun(lock,i):

	with lock:
		print "Using Lock: ", i


if __name__ == '__main__':

	l = Lock()

	for i in range(5):
		p = Process(target=fun, args=(l,i))
		p.start()
		p.join()

