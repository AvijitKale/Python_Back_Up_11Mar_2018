from multiprocessing import Process, Queue

def fun(queue):

	queue.put(["A", 345, None])

if __name__ == '__main__':
	
	q = Queue()
	p = Process(target=fun, args=(q,))
	
	p.start()

	print q.get()

	p.join()
