from multiprocessing import Process, Lock


def fun(l,i):
	with l:
		print "Using with :: process number: ", i
		

	l.acquire()

	print "acquiring lock: ", i

	l.release()

	print "Releasing Lock: ", i
	print "\n\n"

if __name__ == '__main__':

	lock = Lock()

	for i in range(10):
		p = Process(target=fun, args=(lock, i))
		p.start()
