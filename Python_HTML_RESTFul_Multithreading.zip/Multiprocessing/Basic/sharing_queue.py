import multiprocessing


def func(num, q):

	for n in num:
		q.put(n*n)


if __name__ == '__main__':
	
	num = [2,3,4]

	q = multiprocessing.Queue()

	p = multiprocessing.Process(target=func, args=(num, q))

	p.start()

	p.join()

	while not q.empty():
		print q.get()


	
