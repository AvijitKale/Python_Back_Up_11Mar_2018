import re
import collections

pat = re.compile('\d+')
count  = collections.defaultdict(int)


file = "/home/avijit/Python_Scripts/Python_interview_QnA.odt"


def getchunks(file,size=100*100):
	f = open(file)
	while 1:
		start = f.tell()
		print "Start: ", start
		f.seek(size,1)
		print "Size: ", size
		s = f.readline()
		yield  start, f.tell()-start
		if not s:
			break


def process(file,chunk):
	f = open(file)
	f.seek(chunk[0])
	d = collections.defaultdict(int)
	for page in pat.findall(f.read(chunk[1])):
		d[page] += 1
	return d


for chunk in getchunks(file):
	print chunk
	for key,value in process(file,chunk).items():
		count[key] += value

for k,v in count.items():
	print k, "=>>", v
	
