from configtreeview.tools import DataFormatter

data = [ #The DataFormatter is expecting a list of dicts...each dict is a row following the ConfigTreeView Data Model
        {'column_1': {'markup': 'Some data here'}, 'column_2': {'markup': 'Column 2 data here'}},
        {'column_1': {'markup': 'More data col1'}, 'column_2': {'markup': 'Column 2 data here'}},
        {'column_1': {'markup': 'Even more data here'}, 'column_2': {'markup': 'Column 2 data here'}},
]

#Create the DataFormatter
data_formatter = DataFormatter(my_treeview.index_map, mytreeview.types)

#Get a treemodel
liststore = my_treeview.get_treemodel() #Use this function to have your treeview build you a proper GtkTreeModel instance
my_treeview.set_model(liststore)

#Format the data rows for liststore and append them to it
for row in data_formatter.get_rows(data):
        liststore.append(row)
