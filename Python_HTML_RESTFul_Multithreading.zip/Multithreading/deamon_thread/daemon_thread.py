import threading
import time




def creator1():
    global total

    for i in range(10):
        time.sleep(2)
        total += 1

        print ("Adding to total")

    print ("Creator1 is done")


def creator2():
    global total

    for i in range(7):
        time.sleep(1)

        total += 1

        print ("Adding to total from creator2 ")

    print ("Creator 2 is done")



def limitor():

    global total

    while True:
        if total > 5:
            print ("Overload")

            total -= 3

            print("Subtracted 3")

        else:
            time.sleep(1)
            print("Waiting")


if __name__ == '__main__':
    global total

    total = 4

    t1 = threading.Thread(target=creator1)
    t2 = threading.Thread(target=creator2)
    l1 = threading.Thread(target=limitor)

    l1.daemon = True

    print l1.isDaemon()

    t1.start()
    t2.start()
    l1.start()

    t1.join()
    t2.join()
#    l1.join()


    print ("Main Finished: Total is : "), total

