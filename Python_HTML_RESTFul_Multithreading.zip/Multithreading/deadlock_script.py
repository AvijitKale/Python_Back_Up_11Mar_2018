import threading, time

a = 5
alock = threading.Lock()
b = 5
block = threading.Lock()
a1flag =  True



def thread1calc():
    try:
        print "Thread1 acquiring lock a"
        alock.acquire()
#	a += 5
#        time.sleep(5)
 
    finally:
#	if a2flag == True:
       print "Thread1 releasing a locks"
       alock.release()
       a1flag = True 
#	else:
#	    print "I am in deadlock"

    try:
        print "Thread1 acquiring lock b"
        block.acquire()
#	b += 5
#        time.sleep(5)
    finally:
#	if b2flag == True: 
        print "Thread1 releasing both locks"

        block.release()
        b1flag = True
#	else:
#	    print "I am in deadlock"

def thread2calc():
    try:
        print "Thread2 acquiring lock b"
        block.acquire()
#	b += 5
#        time.sleep(5)
    finally:
	if b1flag == True:
	    print "Thread2 releasing b locks"
            block.release()
#	    b2flag = true

	else:
	    print "I am in deadlock"

    try:
        print "Thread2 acquiring lock a"
        alock.acquire()
#	a += 5
#        time.sleep(5)
        
    finally:
	if a1flag ==  True:
            print "Thread2 releasing a locks"
            alock.release()
#	    a2flag = True
	else:
	    print "I am in deadlock"


t1 = threading.Thread(target = thread1calc)
#t1.setDaemon(1)
t1.start()
t1.join(2)


t2 = threading.Thread(target = thread2calc)
#t2.setDaemon(2)
t2.start()
t2.join(2)


#while(t1.isAlive() or t2.isAlive()): 
#    t1.join()
#    t2.join()

print "I am exiting"

#while 1:
    # Sleep forever
#    time.sleep(2)

