import threading

def do_this():
    global x, lock

    lock.acquire()

    try:
        print "This is the first thread"

        while (x < 300):
	    x += 1

        print x

    finally:
 	lock.release()
#        pass


def do_after():
    global x, lock

    print "I am in second thread"
    lock.acquire()
    try:
        print "This is the second thread"

        while (x < 600):
            x += 1

        print x

    finally:
	lock.release()


def main():
    global x, lock

    x = 0
  
    lock = threading.Lock()

    first_thread = threading.Thread(target=do_this, name = "First_Thread")
    second_thread = threading.Thread(target=do_after, name = "Second_Thread")

    first_thread.start()
    second_thread.start()


    first_thread.join()
#    second_thread = threading.Thread(target=do_after, name = "Second_Thread")

#    second_thread.start()
    second_thread.join()


if (__name__ == "__main__"):
    main()
