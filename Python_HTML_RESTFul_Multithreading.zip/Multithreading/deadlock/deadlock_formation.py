#coding=utf-8 
import time 
import threading 
class Account: 
  def __init__(self, _id, balance, lock): 
    self.id = _id 
    self.balance = balance 
    self.lock = lock 
 
  def withdraw(self, amount): 
    self.balance -= amount 
 
  def deposit(self, amount): 
    self.balance += amount 

  def print_info(self):
    print "Info: ", _id, balance , amount
 
 
def transfer(_from, to, amount): 
  if _from.lock.acquire():# Lock your account 
    print "{0} Acquired Lock".format(_from) 
    _from.withdraw(amount) 
    print "{0} withdraw amount ".format(_from.withdraw(amount))
    time.sleep(1)# Let the transaction time becomes longer ，2 Time overlap ， Have enough time to make a life and death lock  
    print 'wait for lock...' 
    if to.lock.acquire():# Lock in each other's account  
      print "{0} Acquired Lock".format(to)
      to.deposit(amount)
      print "{0} deposit amount ".format(to.deposit(amount)) 
      to.lock.release() 
      print "{0} Releasing Lock".format(to)
    _from.lock.release() 
    print "{0} Releasing Lock".format(_from)
  print 'finish...' 
 
a = Account('a',1000, threading.Lock()) 
b = Account('b',1000, threading.Lock()) 
threading.Thread(target = transfer, args = (a, b, 100)).start() 
threading.Thread(target = transfer, args = (b, a, 200)).start() 
