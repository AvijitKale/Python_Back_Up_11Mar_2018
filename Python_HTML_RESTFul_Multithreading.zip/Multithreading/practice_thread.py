import threading

def first_fun():
	
	global x

	while (x <10):
		print "\n\nI am in thread1 :: \n\n"
		print x
		x += 1
	print "I am exiting thread1: \n\n\n"
	
def second_fun():
	global x


	while(x<15):
		print "\n\n\n I am in thread2 ::\n\n"
		print x
		x += 1

	print "I am exiting thread2: \n\n\n"

if __name__ == '__main__':


	global x

	x= 0

	thread1 = threading.Thread(target=first_fun )


	#thread1.daemon = True	

		
	thread1.start()

	thread1.join()   ## If thread1.join() is put here before thread2.start().. thread1 will finish up first and then thread2 will start 

	thread2 = threading.Thread(target=second_fun)


	#thread2.daemon = True

	
	thread2.start()	
#	thread1.join()    ## If its put here.. thread1 and thread2 will start randomly and they may overlap each other...
	
	thread2.join()

	print "\n\n\nI am exiting Main"


