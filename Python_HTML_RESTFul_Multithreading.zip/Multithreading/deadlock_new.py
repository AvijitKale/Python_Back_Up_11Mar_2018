import time
import inspect
import threading


count = 0
lock = threading.Lock()

def incre():
    global count
    print "Acquiring Lock"
    lock.acquire()
    try:
#        count += 1    
	print "Count:", count , "\n"
    finally:
	print "Releasing Lock"
        lock.release()


def bye():
    while True:
        print "BYE: "
        incre()

def hello_there():
    while True:
        print "hello:"
        incre()

def main():    
    hello = threading.Thread(target=hello_there)
    goodbye = threading.Thread(target=bye)
    hello.start()
    goodbye.start()
    hello.join(1)
    goodbye.join(1)

if __name__ == '__main__':
    main()
