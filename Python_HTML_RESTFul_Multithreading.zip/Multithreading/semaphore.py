import threading
import time


class ThreadPool(object):

	def __init__(self):
		super(ThreadPool, self).__init__()
		self.active = []
		self.lock = threading.Lock()

	def MakeActive(self,name):
		with self.lock:
			print "Acquiring lock, {0}".format(name)
			self.active.append(name)
			print "Running threads:{0}".format(self.active)

	def MakeInactive(self,name):
		with self.lock:
			print "Releasing lock, {0}".format(name)
			self.active.remove(name)
			print "Running threads :{0} ".format(self.active)


def fun(s,pool):
	print "Waiting to join the pool"

	with s:
		name = threading.currentThread().getName()
		pool.MakeActive(name)
		time.sleep(3)
		pool.MakeInactive(name)



if __name__ == '__main__':
	pool = ThreadPool()
	s = threading.Semaphore(4)

	for i in range(10):
		t = threading.Thread(target=fun, name='thread-' + str(i), args=(s,pool))
		t.start()


