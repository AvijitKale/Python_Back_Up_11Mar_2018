from threading import Thread

def myfunc():
    print "hello, world!"


thread1 = Thread(target=myfunc)
thread2 = Thread(target=myfunc)

while True:
    thread1.start()
#thread1.join()
    thread2.start()
#thread2.join()
