import threading

def do_this():
    global x, lock
    print "I am in second thread"

    with lock:
        print "This is the first thread"

        while (x < 50):
	    x += 1
	    print x

        print "Final: in first thread :", x



def do_after():
    global x, lock

    print "I am in second thread"
    with lock:
        print "This is the second thread"

        while (x < 100):
            x += 1
            print x

        print "Final in second thread: ", x



def main():
    global x, lock

    x = 0
  
    lock = threading.Lock()

    first_thread = threading.Thread(target=do_this, name = "First_Thread")
    second_thread = threading.Thread(target=do_after, name = "Second_Thread")

    first_thread.start()
    first_thread.join()
    second_thread.start()


#    first_thread.join()
#    second_thread = threading.Thread(target=do_after, name = "Second_Thread")

#    second_thread.start()
    second_thread.join()


if (__name__ == "__main__"):
    main()
