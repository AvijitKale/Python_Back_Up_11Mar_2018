import threading, time

a = 5
alock = threading.Lock()
b = 5
block = threading.Lock()
#a1flag =  True



def thread1calc():
    try:
        print "Thread1 acquiring lock a"
        alock.acquire()
 
    finally:
        print "Thread1 releasing a locks"
        alock.release()

    try:
        print "Thread1 acquiring lock b"
        block.acquire()
    finally:
        print "Thread1 releasing b lock"
        block.release()

def thread2calc():
    try:
        print "Thread2 acquiring lock b"
        block.acquire()
    finally:
        print "Thread2 releasing b locks"
        block.release()

    try:
        print "Thread2 acquiring lock a"
        alock.acquire()
        
    finally:
        print "Thread2 releasing a locks"
        alock.release()


t1 = threading.Thread(target = thread1calc)
#t1.setDaemon(1)
t1.start()
t1.join()


t2 = threading.Thread(target = thread2calc)
#t2.setDaemon(2)
t2.start()
t2.join()


print "I am exiting"


