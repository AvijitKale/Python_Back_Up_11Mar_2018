import threading
import time

exitFlag = 0

class myThread(threading.Thread):
    def __init__(self,threadID,threadName,delay):
#	threading.Thread.__init__(self)
	self.threadID = threadID
	self.threadName = threadName
	self.delay = delay

    def run(self):
	print "Starting thread {0}".format(self.threadID)
	prime_time(self.threadName,self.delay,5)
	print "Exiting thread {0}".format(self.threadID)


def prime_time(threadName,delay,counter):
    while counter:
        if exitFlag:
            threadName.exit()
        time.sleep(delay)
        print "{0}{1}".format(threadName,time.ctime(time.time()))
        counter -= 1


thread1 = myThread(1,"Thread1",1)
thread2 = myThread(2,"Thread2",2)

thread1.start()
thread2.start()
	
