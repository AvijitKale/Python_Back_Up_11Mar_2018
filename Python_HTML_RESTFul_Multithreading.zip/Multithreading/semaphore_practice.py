import time
import threading


class ThreadPool(object):

	def __init__(self):
		super(ThreadPool, self).__init__()
		self.active = []
		self.lock = threading.Lock()

	def MakeActive(self,name):
		with self.lock:
			print "Acquiring the Lock: {0}".format(name)
			self.active.append(name)
			print "Current Self Active list: {0}".format(self.active)

	def MakeInactive(self,name):
		with self.lock:
			print "Releasing the Lock: {0}".format(name)
			self.active.remove(name)
			print "Current Self Active list: {0}".format(self.active)


def func(s,pool):

	print "Waiting to join the pool"

	with s:
		name = threading.currentThread().getName()
		pool.MakeActive(name)
		time.sleep(2)
		pool.MakeInactive(name)


if __name__ == '__main__':
	pool = ThreadPool()

	s = threading.Semaphore(4)

	for i in range(10):
		t = threading.Thread(target=func, name = "thread-" + str(i) , args=(s,pool))
		t.start()







