import threading
import time


def fun1():
	print "First Thread Starts"
	time.sleep(3)
	print "First Thread Ends"


def fun2():
	print "Second Thread Starts"
	time.sleep(4)
	print "Second Thread Ends"



def main():
	t1 = threading.Thread(target=fun1, name="First")
	t2 = threading.Thread(target=fun2, name="Second")

	t1.start()
	t1.join(2)
	t2.start()
	t2.join()


if __name__ == "__main__":
	main()


