import time
import inspect
import threading

class Thread(threading.Thread):
    def __init__(self, t, *args):
        threading.Thread.__init__(self, target=t, args=args)
        self.start()

count = 0
lock = threading.Lock()

def incre():
    global count
    print "Acquiring Lock"
    lock.acquire()
    try:
        count += 1    
	print "Count:", count , "\n"
    finally:
	print "Releasing Lock"
        lock.release()


def bye():
    print "BYE: "
    while count <10:
        incre()

def hello_there():
    print "hello:"
    while count < 10:
        incre()

def main():    
    hello = Thread(hello_there)
    goodbye = Thread(bye)
    hello.join()
    goodbye.join()

if __name__ == '__main__':
    main()
