import threading
import time


tlock = threading.Lock()

def func(name, delay, repeat):


	tlock.acquire()

	print name + ": " + "Lock Acquired \n"

	print name + ": " + "started \n" 

	while repeat > 0:
		time.sleep(delay)
		print  name + ": " + str(time.ctime(time.time()))
		repeat -= 1

	tlock.release()

	print name + ": " + "Lock Released \n"

	print name + ": " + "finished \n"



if __name__ == '__main__':

	t1 = threading.Thread(target=func , args=("Thread1", 1, 5))

	t2 = threading.Thread(target=func , args=("Thread2", 2, 5))

	t1.start()

	t2.start()

	print "Main Completed"
		
		

	



