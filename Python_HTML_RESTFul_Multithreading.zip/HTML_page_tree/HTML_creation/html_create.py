

#def application(environ, start_response):

page = "<html><body><h1>Hello World</h1></body></html>"
headers = [('content-type', 'text/html')]
start_response('200 OK', headers)
print [page.encode()]
