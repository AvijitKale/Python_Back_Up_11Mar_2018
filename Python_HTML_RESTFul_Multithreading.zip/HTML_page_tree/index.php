<!DOCTYPE html>
<html>
<head>
	<title> PHP File with Ajax</title>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css"/>
	<script type="text/javacsript charset="utf8" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-treeview/1.2.0/bootstrap-treeview.min.js"></script>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-treeview/1.2.0/bootstrap-treeview.min.css"/>
	<style>
	</style>
</head>
<body>
	<br/><br/>
	<div class="container" style=width:900px;">
		<h2 align="center"> Make treeview</h2>
		<br/><br/>
		<div id="treeview"></div>
	</div>
</body>
</html>
<script>
$(document).ready(function() {
  $.ajax({
    url: 'fetch.php',
    method: 'POST',
    datatype: 'json',
    success: function(data) {
      var treeDataArr = data;
      treeDataArr = JSON.parse(treeDataArr); //Comment this if you get an error
      var treeJSON = [];
      var parentNodesArr = [{id: 0, nodes: []}];
      while (parentNodesArr.length > 0) {
        var parentNode = parentNodesArr[0];

        var parentId = parentNode.id;
        if (parentId == 0) {
          parentNodes = treeJSON;
        } else {
          parentNodes = parentNode.nodes;
        }
        parentNodesArr.splice(0, 1);
        for (var i = 0; i < treeDataArr.length; i++) {
          var node = treeDataArr[i];
          if (node.parent_id == parentId) {
            node.text = node.name;
            node.nodes = [];
            parentNodes.push(node);
            parentNodesArr.push(node);
          }
        }
      }

      $('#treeview').treeview({data: treeJSON});
    });
});


</script>
		
