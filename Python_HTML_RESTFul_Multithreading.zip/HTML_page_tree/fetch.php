<?php

$con=mysqli_connect('localhost', 'root', 'root');


mysqli_select_db($con, 'MyDB');


$qry="SELECT * FROM treeview_items";

$result=mysqli_query($con,$qry);

while($row = mysqli_fetch_array($result))
{
	$sub_data["id"] = $row["id"];
	$sub_data["name"] = $row["name"];
	$sub_data["parent_id"] = $row["parent_id"];	
	$data[] = $sub_data;
}
/*

foreach($data as $key => &$value)
{
	$output[$value["id"]] = &$value;
}



foreach($data as $key => &$value)
{
	if($value["parent_id"] && isset($output[$value["parent_id"]]))
	{
		$output[$value["parent_id"]]["nodes"][] = &$value;
	}
}


foreach($data as $key => &$value)
{
	if($value["parent_id"] && isset($output[$value["parent_id"]]))
	{
		unset($data[$key]);
	}
}
*/
echo json_encode($data);

//echo json_encode(array("Apple", "Banana", "Pear"));

$val = json_encode($data);
if($val === false || is_null($val)){
    throw new Exception('Could not encode JSON');
}
else{
echo $val;
}


#echo '<pre>';
#print_r($data);
#echo '</pre>';

?>
