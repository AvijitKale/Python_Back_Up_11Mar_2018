<body>
<link rel="stylesheet" type="text/css" href="_styles.css" media="screen">


<?php
function createTreeView($array, $currentParent, $currLevel = 0, $prevLevel = -1) {

foreach ($array as $categoryId => $category) {

if ($currentParent == $category['parent_id']) {
    if ($currLevel > $prevLevel) echo " <ol class='tree'> ";

    if ($currLevel == $prevLevel) echo " </li> ";

    echo '<li> <label for="subfolder2">'.$category['name'].'</label> <input type="checkbox" name="subfolder2"/>';

    if ($currLevel > $prevLevel) { $prevLevel = $currLevel; }

    $currLevel++;

    createTreeView ($array, $categoryId, $currLevel, $prevLevel);

    $currLevel--;
    }

}

if ($currLevel == $prevLevel) echo " </li>  </ol> ";

}
?>



<?php
mysqli_connect('localhost', 'root', 'root');





#$conn = new mysqli('localhost', 'root', 'root');

mysqli_select_db('MyDB');
 
 
$qry="SELECT * FROM treeview_items";
$result=mysqli_query($qry);
 
 
$arrayCategories = array();
 
while($row = mysqli_fetch_assoc($result)){ 
 $arrayCategories[$row['id']] = array("parent_id" => $row['parent_id'], "name" =>                       
 $row['name']);   
  }
?>
<div id="content" class="general-style1">
<?php
if(mysqli_num_rows($result)!=0)
{
?>
<?php 
 
createTreeView($arrayCategories, 0); ?>
<?php
}
?>
 
</div>
</body>
</html>



