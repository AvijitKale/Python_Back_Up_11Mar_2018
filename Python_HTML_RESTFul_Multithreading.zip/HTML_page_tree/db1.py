#import MySQLdb

import mysql.connector

conn = mysql.connector.connect(host='localhost',user='root',passwd='root',database='user')

mycursor=conn.cursor()
mycursor.execute("select username from user where username=%s", a.username)
