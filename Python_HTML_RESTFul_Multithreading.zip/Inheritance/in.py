class FooBase(object):
    def foo(self): pass

class A(FooBase):
    def foo(self):
        super(A, self).foo()
        print 'Go A Go'

class B(FooBase):
    def foo(self):
        super(B, self).foo()
        print 'go B Go'

class C(A, B):
    def foo(self):
        super(C, self).foo()
        print 'Go C Go'

C().foo()  # Run this
