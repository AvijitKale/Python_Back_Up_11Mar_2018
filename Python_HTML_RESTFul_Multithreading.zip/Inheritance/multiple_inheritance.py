class A(object):
	def go(self):
		print "Go A Go"

class B(A):
        def go(self):
		super(B, self).go()
                print "Go B Go"


class C(A):
        def go(self):
		super(C, self).go()
                print "Go C Go"



"""  This list of MRO always gets printed in Reverse Manner.  Since print is after super"""


class D(B,C):        ###MRO   D B A C A    ===>  D B C A   ## Last but all other repeated gets canceled
        def go(self):
		super(D, self).go()
                print "Go D Go"


class E(C,B):        ###MRO    E C A B A     ==>  E C B A 
        def go(self):
		super(E, self).go()
                print "Go E Go"



print "Class D inheritance list: D B C A ===> Will be Printed reverse Since Super is called before print "

d = D()
d.go()

print "Class E inheritance list: E C B A ===> Will be Printed reverse since Super is called before print"

e = E()
e.go()
