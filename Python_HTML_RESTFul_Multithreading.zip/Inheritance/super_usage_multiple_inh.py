class FooBase(object):
    def foo(self):
        print 'FooBase.foo()'

class A(FooBase):
    def foo(self):
        print 'A.foo() before super()'
        super(A, self).foo()
        print 'A.foo() after super()'

class B(FooBase):
    def foo(self):
        print 'B.foo() before super()'
        super(B, self).foo()
        print 'B.foo() after super()'

class C(A, B):
    def foo(self):
        print 'C.foo() before super()'
        super(C, self).foo()
        print 'C.foo() after super()'

c = C()

c.foo()
