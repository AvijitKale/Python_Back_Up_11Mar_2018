class A(object):
	def foo(self):
		print "A.Foo"

class B(object):
	def foo(self):
		print "B.Foo"

class C(A,B):
	def foo(self):
		print "C.Foo"
		super(C, self).foo()
		super(A, self).foo()

c = C()

c.foo()
	
