"""
In this case super is called BEFORE the print Check the output is reversed.
"""

class A(object):
    def m(self):
        print("m of A called")

class B(A):
    def m(self):
	super(B, self).m()
        print("m of B called")

class C(A):
    def m(self):
	super(C,self).m()
        print("m of C called")

class D(B,C):
    def m(self):
	super(D,self).m()
        print("m of D called")

d = D()

d.m()
