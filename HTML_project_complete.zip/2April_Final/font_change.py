import codecs
from bs4 import BeautifulSoup
import requests, re
import string

flagPre = False
flagExp = False
flagTable = False


f1 = codecs.open("append.html", 'r', 'utf-8')

f2 = open('new_append.html', 'w')


for line in f1.readlines():
#	print (line)
	if "Preconditions:" in line:
#		print ("inside precon loop:   =====> \n")
		flagPre = True

	if flagPre and ("</div><p>" in line or "<td><p>" in line or "<p>" in line):
#		print ("Found <p> in Pre")
		line = line.replace('<p>','<font size="2" face="Verdana" ><p>' )

	if flagPre and "</p></td>" in line:
#		print ("Found </p></td> in Pre")
		line = line.replace('</p>','</p></font>')


	if "Expected Results:" in line:
#		print ("inside expec loop:   ------> \n")
		flagExp = True
		flagPre = False
	if ("</div><p>" in line or "<td><p>" in line or "<p>" in line) and flagExp:
#		print ("Found p in Exp")
		line = line.replace('<p>','<font size="2" face="Verdana" ><p>')
                       
	if ("</p></td>" in line or "<p>" in line) and flagExp:
#		print ("Found /p in Exp")
		line = line.replace('</p>','</p></font>')

	if "</table>" in line:
		flagTable = True

	if "</font></div>" in line and (flagTable == False):
		flagTable = False
		line = line.replace('</font></div>', '</table></div></font></div>')


	if "</font></div>" in line:
		flagExp = False
		flagPre = False
		flagTable = False

	
	f2.write(line)


f1.close()
f2.close()
	
	
