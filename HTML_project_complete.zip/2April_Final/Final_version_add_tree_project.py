import codecs
from bs4 import BeautifulSoup
import requests, re, os
import sys

#if  len(sys.argv) is not 5:
#	print ("Arguments missing: Arguments must be 5")

html_file = sys.argv[1]

bios_version = sys.argv[2]

AMI_BMC_version = sys.argv[3]

fw_version = sys.argv[4]

linux_os_version = sys.argv[5]




#f = codecs.open("large_html_final.html", 'r', 'utf-8')

f = codecs.open(html_file, 'r', 'utf-8')

flag = True

dict = {}
h2_list = []
h2_dict = {}
tc_list = []
old_head = None
strspace = ' '
flag_tc = False

tc_count = 0


flagA = False
OneTimeFlagA = True
flagB = False
OneTimeFlagB = True
flagC = False
OneTimeFlagC = True

post_line = []


head1 = '<html>'
head2 = '<head>'
head3 = '<link rel="stylesheet" type="text/css" href="mystyle_ver1.css"> '

head4 = '<script src="http://code.jquery.com/jquery-1.7.1.min.js"></script>'
head5 = '<script src="my.js"></script>'

head6 = '<script src="http://cdn.kendostatic.com/2012.1.124/js/kendo.all.min.js"></script>'
head7 = '<link href="http://cdn.kendostatic.com/2012.1.124/styles/kendo.common.min.css" rel="stylesheet" />'

head8 = '<link href="http://cdn.kendostatic.com/2012.1.124/styles/kendo.default.min.css" rel="stylesheet" />'

head9 = """<style>

	.k-treeview .k-minus {
		
	background: url("folder.png") center center;

	}

	.k-treeview .k-plus {

	background: url("folderopen.png") center center;

	}

	</style>"""




head10 = '</head>'

body1 = '<body>'

div1 = '<div id="example" class="k-content">'

class1 = '<div class="split left">'
class2 = '<div class="nav">'

line = '<ul id="treeview">'

fh = open('final_html.html','w')

fh.writelines("%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n" % (head1, head2, head3, head4, head5, head6, head7, head8, head9, head10))

fh.writelines("%s\n%s\n" % (body1, div1))

fh.write("%s\n%s\n" % (class1, class2))

fh.write(line)

""" Creating new html file which will be appended to main"""

ap_line1 = """<script>

			$(document).ready(function() {

				$("#treeview").kendoTreeView();

			});

		</script>"""

ap_line2 = '</div>'

ap_line3 = '</div>'

ap_line4 = '<div class="split right">'

ap_line5 = """<header>
		<h2>Osprey Test Summary</h2>
		</header>"""

ap_line6 = '<div class="tab-content">'

ap_line7 = """
		<div class="version_bordered"> 
		<table style="margin: 0px auto;"> 
  
  		<tr>
    		<td><b>BIOS Version</b></td>
	   """

ap_line8 = '<td><b>:&emsp;&emsp;' + bios_version + '</b></td> </tr>'

ap_line9 = """<tr>
    <td><b>AMI BMC Version</b></td>"""

ap_line10 = '<td><b>:&emsp;&emsp;' + AMI_BMC_version + '</b></td> </tr>'

ap_line11 = """<tr>
    <td><b>FW Version</b></td> """

ap_line12 = '<td><b>:&emsp;&emsp;' + fw_version + '</b></td> </tr>'

ap_line13 = """<tr>
    <td><b>Linux OS Version</b></td> """
ap_line14 = '<td><b>:&emsp;&emsp;'+ linux_os_version + '</b></td> </tr>'	

ap_line15 = """</table>			    

		</div>
		</div> """


f_ap = open("append.html", "w")

f_ap.writelines("%s\n%s\n%s\n%s\n%s\n%s\n" % (ap_line1, ap_line2 , ap_line3, ap_line4,ap_line5,ap_line6))

f_ap.writelines("%s\n%s\n%s\n%s\n%s\n%s\n" % (ap_line7, ap_line8 , ap_line9, ap_line10,ap_line11,ap_line12))


f_ap.writelines("%s\n%s\n%s\n" % (ap_line13, ap_line14 , ap_line15))


def print_summary(astring, tc_count, test_case):

	init_append_html(tc_count, test_case)
	bstring = astring.split('<span class="label">Summary:</span><br />')
	str_summary  = bstring[1]
	
	tb = '\n' + 6*strspace + '<font size="2" face="Verdana" ><table class="tc" width="90%" >'

	if re.match(r'^<p>', str_summary):
		sm =  '<div id="colorstrip"><b>Summary:</b></div>'

	else:
		sm =  '<div id="colorstrip"><b>Summary:</b></div><p>'

#	sm =  '<div id="colorstrip"><b>Summary:</b></div>'	

	f_ap.write(tb)
	f_ap.write(sm)
	f_ap.write(str_summary)
	

def init_append_html(tc_count, test_case):

	gs = ''.join('\n'+ 6*strspace + '<div id="section-tc'+  str(tc_count) + '"' + 'class="tab-content">')

	hs = '\n' + 6*strspace + '<h4>' + test_case + '</h4>'

	hs_colorstrip = '\n' + 6*strspace + '<div id="colorstrip_TestCase">' +  hs  + '</div>'

	br = '\n' + 6*strspace + '<br>'

	dc = '\n' + 6*strspace + '<div class="bordered">'

	f_ap.write(gs)
	f_ap.write(hs_colorstrip)
	f_ap.write(br)
	f_ap.write(dc)



for line in f.readlines():

#	print (line)
	if re.match(r'<h1.*?>', line):
		
		p = re.compile(r'<([^\s]+)(\s[^>]*?)?(?<!/)>')
		h1_head = p.sub('', line).lstrip("Test Suite :")
		print (h1_head)
		
		if flag_tc:
			p2 = '\n' + 8*strspace + '</ul>'
			fh.write(p2)
			p3 = '\n' + 6*strspace + '</li>'
			fh.write(p3)
			p4 = '\n' + 4*strspace + '</ul>'
			fh.write(p4)
			p5 = '\n' + 2*strspace + '</li>'
			fh.write(p5)
			flag_tc = False
				
		p = ''.join('\n'+ 2*strspace + '<li><a href="#">'+ h1_head.rstrip("\n") +'</a>')
		p  = p + ' '*1
		fh.write(p)
		
		p1 = '\n'+ 4*strspace + '<ul>'
		fh.write(p1)
#		fh.write("\n")
#		print ("H2 List: ", h2_list)
		h2_list = None
		h2_list = []

	if re.match(r'<h2.*?>', line):
		q = re.compile(r'<([^\s]+)(\s[^>]*?)?(?<!/)>')
		h2 = q.sub('', line)
		
		h2_head = h2.split(":")[1]
		h2_head = h2_head.strip("\n")
		print ("\t", h2_head)

		if flag_tc:
			c2 = '\n' + 8*strspace + '</ul>'
			fh.write(c2)
			c3 = '\n' + 6*strspace + '</li>'	
			fh.write(c3)
			flag_tc = False

		c = ''.join('\n'+ 6*strspace + '<li><a href="#">' + h2_head + '</a>')
		fh.write(c)
		c1 = '\n' + 8*strspace + '<ul>'
		fh.write(c1)
		
#		h2_list.append(h2_dict)
		dict[h1_head] = h2_list
		h2_dict = {}
		tc_list = None
		tc_list = []
		

	if re.match(r'<p>.*?>', line):
		p = re.compile(r'<([^\s]+)(\s[^>]*?)?(?<!/)>')
		test_case = p.sub('', line)
		if test_case.startswith('Test'):
			test_case = test_case.rstrip()
			print ("\t\t", test_case)
			tc_count += 1
			gc = ''.join('\n'+ 10*strspace + '<li><a href="#section-tc'+  str(tc_count) + '"' + '>' + test_case + '</a></li>')
			fh.write(gc)
			flag_tc = True
			tc_list.append(test_case)
#		print ("tc_list: ", tc_list)	

		if h2_head not in h2_dict.keys():
			h2_dict[h2_head] = tc_list
			h2_list.append(h2_dict)		
#			print ("H2_dict:", h2_dict)


	if ((re.match(r'<tr.*?>', line) and ("Summary" in line) and ("Preconditions:" not in line) and ("#:" not in line)) or flagC) :
		flagC = True
#		print ("Line: ", line)

		if OneTimeFlagC:
			astring = line
			print_summary(astring, tc_count, test_case)
			OneTimeFlagC = False

		else:
			f_ap.write(line)

		if "</div>" in line:
			f_ap.write("</font></div>")
#			f_ap.write("</div>")
#			f_ap.write("</div>")
#			f_ap.write("\n&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&\n")
#			f_ap.write("\n\n")
			flagC = False
			OneTimeFlagC = True
			post_line = []


	elif ((re.match(r'<tr.*?>', line) and ("Preconditions:" in line)) or flagA):
		flagA = True
#		print ("Line: ", line)	

		
		
		if OneTimeFlagA:
			post_line = line.split("Preconditions:</span><br />")
			astring = post_line[0]
			print_summary(astring, tc_count, test_case)		
			line = post_line[1]
			OneTimeFlagA = False
			f_ap.write('\n')
			
#			f_ap.write('<div> <table class="tc" width="90%" >')
			f_ap.write('<div id="colorstrip"><b><font size="2" face="Verdana" >Preconditions:</font></b></div>')
		

		f_ap.write(line)

		if "</div>" in line:
			f_ap.write("</font></div>")
#			f_ap.write("</div>")
#			f_ap.write("</div>")
#			f_ap.write("\n**************************************************************\n")
#			f_ap.write("\n\n")
			flagA = False
			OneTimeFlagA = True
			post_line = []

#
	elif ((re.match(r'<tr.*?>', line) and ("#:" in line) and ("Preconditions:" not in line)) or flagB):
		flagB = True
#		print ("Line: ", line)

		if OneTimeFlagB:
			post_line = line.split('<tr><td><span class="label">#:</span>')
			astring = post_line[0]
			print_summary(astring, tc_count, test_case)
			line = post_line[1]
			OneTimeFlagB = False
#			f_ap.write('<div> <table class="tc" width="90%" >')
			
			f_ap.write('<tr><td><span class="label">#:</span>')


		f_ap.write(line)

		if "</div>" in line:
			f_ap.write("</font></div>")
#			f_ap.write("</div>")
#			f_ap.write("</div>")
#			f_ap.write("\n###############################################################\n")
#			f_ap.write("\n\n")
			flagB = False
			OneTimeFlagB = True
			post_line = []



footer = '<footer>Copyright &copy; Ampere Computing</footer>'
f_ap.write(footer)
ds_end = '</div>'
f_ap.write(ds_end)
f_ap.close()	

if flag_tc:
	p2 = '\n' + 8*strspace + '</ul>'
	fh.write(p2)
	p3 = '\n' + 6*strspace + '</li>'
	fh.write(p3)
	p4 = '\n' + 4*strspace + '</ul>'
	fh.write(p4)
	p5 = '\n' + 2*strspace + '</li>'
	fh.write(p5)
	p6 = '\n' + strspace + '</ul>'
	fh.write(p6)
	p7 = '\n' + strspace + '</div>'
	fh.write(p7)
	p8 = '\n' + strspace + '</div>'
	fh.write(p8)
	flag_tc = False


old_str = '<tr><td><span class="label">#:</span></td><td><span class="label">Step actions:</span></td><td><span class="label">Expected Results:</span></td></tr>'


new_str = '<tr><td><div id="colorstrip"><b><font size="2" face="Verdana" >#:</font></b></div></td><td><div id="colorstrip"><b><font size="2" face="Verdana" >Step actions:</font></b></div></td><td><div id="colorstrip"><b><font size="2" face="Verdana" >Expected Results:</font></b></div></td></tr>'

pre_old = '<span class="label">Preconditions:</span><br /><p>'

pre_new = '<div id="colorstrip"><b><font size="2" face="Verdana" >Preconditions:</font></b></div><p>'

old_width = 'width="20%"'

new_width = 'width="27%"'

old_extype = '<tr><td width="27%" valign="top"><span class="label">Execution type:</span></td><td colspan="2">Manual</td></tr>'

new_extype = '<tr><td width="27%" valign="top"><span class="label"><font size="2" face="Verdana" ><b>Execution type:</b></font></span></td><td colspan="2"><font size="2" face="Verdana" >Manual</font></td></tr>'

s = open("append.html").read()
s = s.replace(old_str, new_str)
s = s.replace(pre_old, pre_new)
s = s.replace(old_width,new_width)
s = s.replace(old_extype,new_extype)
f = open("append.html", 'w')
f.write(s)
f.close()


cmd = "python font_change.py"

os.system(cmd)




print("\n\n************  Printing Dictionary key value pairs: ***********\n\n")

""" Appending the new_append.html to main html  """

f_div = open("new_append.html", "r")
div_read = f_div.read()
f_div.close()
fh.write("\n\n")
fh.write(div_read)

""" Appending the Java script to main html  """


fin = open("js_file.txt", "r")
data2 = fin.read()
fin.close()
fh.write("\n\n")
fh.write(data2)
fh.close()


for k, v in dict.items():
	print (k , "=>", v)
	print ("\n")
