A tree menu plugin for jQuery framework 

Example :
http://jsfiddle.net/nnLg07ag/10/

Jquery Directory Tree Plugin
