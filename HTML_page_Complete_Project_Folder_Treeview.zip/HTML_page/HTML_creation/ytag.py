from yattag import Doc

doc, tag, text = Doc().tagtext()

dict = {'A':'apple','B':'Banana'}


with tag('html'):
	with tag('body'):
		for k, v in dict.items():
        		with tag('h1'):
        			text(k)
        		with tag('h2'):
        			text(v)

result = doc.getvalue()

with open("doc.html", "w") as f:
	f.write(result)
