import lxml.etree as et
#from dict_exp import test_dict



def data2xml(d, name='data'):
    r = et.Element(name)
    return et.tostring(buildxml(r, d))

def buildxml(r, d):
    if isinstance(d, dict):
        for k, v in d.iteritems():
            s = et.SubElement(r, k)
            buildxml(s, v)
    elif isinstance(d, tuple) or isinstance(d, list):
        for v in d:
            s = et.SubElement(r, 'x')
            buildxml(s, v)
    elif isinstance(d, basestring):
        r.text = d
    else:
        r.text = str(d)
    return r

#print data2xml({'a':[1,2,('c',{'d':'e'})],'f':'g'})


#print data2xml(test_dict)

print data2xml({'BIOS':[{'ATF_CoT':['Test Case OSP_SW-2141: ATF_BL33\n','Test Case OSP_SW-2140: ATF_BL32\n','Test Case OSP_SW-2139: ATF_BL31\n']},{'BMC': ['Test Case OSP_SW-77: AMI_BMC_support\n','Test Case OSP_SW-78: AMI_BMC_Wait_for_BMC\n','Test Case OSP_SW-79: AMI_BMC_FRB2_Timer\n','Test Case OSP_SW-89: AMI_BMC_warm_reset\n','Test Case OSP_SW-5641: AMI_Platform_GFC_clock\n','Test Case OSP_SW-5640: AMI_Platform_AHB_clock\n']}]})

