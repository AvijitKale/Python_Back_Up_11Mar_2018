filename = "sample.html"
head1 = '<head>'
head2 = '<link rel="stylesheet" type="text/css" href="mystyle.css"> '
head3 = '</head>'

line = '<ul class="tree">'


with open(filename,'wb') as f:
	f.writelines("%s\n%s\n%s\n" % (head1, head2, head3))

	f.write(line)

