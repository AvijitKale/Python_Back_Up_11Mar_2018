test_case =  "Test Case 1"

strspace = " "

tc_count = 1

fh = open("1.html", "w")

gc = ''.join('\n'+ 10*strspace + '<li><a href="section-tc'+  str(tc_count) + '"' + '>' + test_case + '</a></li>')

fh.write(gc)


