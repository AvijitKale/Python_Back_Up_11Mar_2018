import codecs
from bs4 import BeautifulSoup
import requests, re
import lxml.etree as et


def dict_create(f):

	flag = True

	dict = {}
	h2_list = []
	h2_dict = {}
	tc_list = []
	old_head = None


	for line in f.readlines():
#	print (line)
		if re.match(r'<h1.*?>', line):
		
			p = re.compile(r'<([^\s]+)(\s[^>]*?)?(?<!/)>')
			h1_head = p.sub('', line).lstrip("Test Suite :")
			print (h1_head)
#			print ("H2 List: ", h2_list)
			h2_list = None
			h2_list = []

		if re.match(r'<h2.*?>', line):
			q = re.compile(r'<([^\s]+)(\s[^>]*?)?(?<!/)>')
			h2 = q.sub('', line)
		
			h2_head = h2.split(":")[1]
			h2_head = h2_head.strip("\n")
			print ("\t", h2_head)
#			h2_list.append(h2_dict)
			dict[h1_head] = h2_list
			h2_dict = {}
			tc_list = None
			tc_list = []
		

		if re.match(r'<p>.*?>', line):
			p = re.compile(r'<([^\s]+)(\s[^>]*?)?(?<!/)>')
			test_case = p.sub('', line)
			if test_case.startswith('Test'):
				test_case = test_case
				print ("\t\t", test_case)
				tc_list.append(test_case)
#			print ("tc_list: ", tc_list)	

			if h2_head not in h2_dict.keys():
				h2_dict[h2_head] = tc_list
				h2_list.append(h2_dict)		
#				print ("H2_dict:", h2_dict)
	
	return dict
	
def data2xml(d, name='data'):
    r = et.Element(name)
    return et.tostring(buildxml(r, d))

def buildxml(r, d):
    if isinstance(d, dict):
        for k, v in d.iteritems():
            s = et.SubElement(r, k)
            buildxml(s, v)
    elif isinstance(d, tuple) or isinstance(d, list):
        for v in d:
            s = et.SubElement(r, 'i')
            buildxml(s, v)
    elif isinstance(d, basestring):
        r.text = d
    else:
        r.text = str(d)
    return r




test_dict = {}

f = codecs.open("concise_new.html", 'r', 'utf-8')

test_dict = dict_create(f)


print("\n\n************  Printing Dictionary key value pairs: ***********\n\n")

for k, v in test_dict.items():
        print (k , "=>", v)
        print ("\n")

dict1 = {'BMC':[{'web': [1,2]},{'ipmi': [3,4]}]}


print (data2xml(dict1))


