import codecs
from bs4 import BeautifulSoup
import requests, re

#soup = BeautifulSoup(open("concise_new.html"), 'html.parser')

f = codecs.open("concise_new.html", 'r', 'utf-8')

flag = True

dict = {}
h2_list = []
old_head = 0


for line in f.readlines():
#	print (line)
	if re.match(r'<h1.*?>', line):
		
		p = re.compile(r'<([^\s]+)(\s[^>]*?)?(?<!/)>')
		h1_head = p.sub('', line).lstrip("Test Suite :")
		print (h1_head)
		print ("H2 List: ", h2_list)
		h2_list = None
		h2_list = []

	if re.match(r'<h2.*?>', line):
		q = re.compile(r'<([^\s]+)(\s[^>]*?)?(?<!/)>')
		h2_head = q.sub('', line)
		
		h2_new = h2_head.split(":")[1]
		h2_new = h2_new.strip("\n")
		print ("\t", h2_new)
		h2_list.append(h2_new)
		dict[h1_head] = h2_list


print("\n\n************  Printing Dictionary key value pairs: ***********\n\n")

for k, v in dict.items():
	print (k , "=>", v)
