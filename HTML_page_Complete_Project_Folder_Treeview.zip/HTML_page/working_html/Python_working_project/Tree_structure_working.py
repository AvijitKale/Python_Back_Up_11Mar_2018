import codecs
from bs4 import BeautifulSoup
import requests, re


f = codecs.open("concise_new.html", 'r', 'utf-8')

flag = True

dict = {}
h2_list = []
h2_dict = {}
tc_list = []
old_head = None
strspace = ' '
flag_tc = False

tc_count = 0


head1 = '<head>'
head2 = '<link rel="stylesheet" type="text/css" href="mystyle.css"> '
head3 = '</head>'

class1 = '<div class="split left">'
class2 = '<div class="nav">'

line = '<ul class="tree">'

fh = open('tree.html','w')

fh.writelines("%s\n%s\n%s\n" % (head1, head2, head3))

fh.write("%s\n%s\n" % (class1, class2))

fh.write(line)

for line in f.readlines():

#	print (line)
	if re.match(r'<h1.*?>', line):
		
		p = re.compile(r'<([^\s]+)(\s[^>]*?)?(?<!/)>')
		h1_head = p.sub('', line).lstrip("Test Suite :")
		print (h1_head)
		
		if flag_tc:
			p2 = '\n' + 8*strspace + '</ul>'
			fh.write(p2)
			p3 = '\n' + 6*strspace + '</li>'
			fh.write(p3)
			p4 = '\n' + 4*strspace + '</ul>'
			fh.write(p4)
			p5 = '\n' + 2*strspace + '</li>'
			fh.write(p5)
			flag_tc = False
				
		p = ''.join('\n'+ 2*strspace + '<li><a href="#">'+ h1_head.rstrip("\n") +'</a>')
		p  = p + ' '*1
		fh.write(p)
		
		p1 = '\n'+ 4*strspace + '<ul>'
		fh.write(p1)
#		fh.write("\n")
#		print ("H2 List: ", h2_list)
		h2_list = None
		h2_list = []

	if re.match(r'<h2.*?>', line):
		q = re.compile(r'<([^\s]+)(\s[^>]*?)?(?<!/)>')
		h2 = q.sub('', line)
		
		h2_head = h2.split(":")[1]
		h2_head = h2_head.strip("\n")
		print ("\t", h2_head)

		if flag_tc:
			c2 = '\n' + 8*strspace + '</ul>'
			fh.write(c2)
			c3 = '\n' + 6*strspace + '</li>'	
			fh.write(c3)
			flag_tc = False

		c = ''.join('\n'+ 6*strspace + '<li><a href="#">' + h2_head + '</a>')
		fh.write(c)
		c1 = '\n' + 8*strspace + '<ul>'
		fh.write(c1)
		
#		h2_list.append(h2_dict)
		dict[h1_head] = h2_list
		h2_dict = {}
		tc_list = None
		tc_list = []
		

	if re.match(r'<p>.*?>', line):
		p = re.compile(r'<([^\s]+)(\s[^>]*?)?(?<!/)>')
		test_case = p.sub('', line)
		if test_case.startswith('Test'):
			test_case = test_case.rstrip("\n")
			print ("\t\t", test_case)
			tc_count += 1
			gc = ''.join('\n'+ 10*strspace + '<li><a href="section-tc'+  str(tc_count) + '"' + '>' + test_case + '</a></li>')
			fh.write(gc)
			flag_tc = True
			tc_list.append(test_case)
#		print ("tc_list: ", tc_list)	

		if h2_head not in h2_dict.keys():
			h2_dict[h2_head] = tc_list
			h2_list.append(h2_dict)		
#			print ("H2_dict:", h2_dict)
	
		

	

if flag_tc:
	p2 = '\n' + 8*strspace + '</ul>'
	fh.write(p2)
	p3 = '\n' + 6*strspace + '</li>'
	fh.write(p3)
	p4 = '\n' + 4*strspace + '</ul>'
	fh.write(p4)
	p5 = '\n' + 2*strspace + '</li>'
	fh.write(p5)
	p6 = '\n' + strspace + '</ul>'
	fh.write(p6)
	p7 = '\n' + strspace + '</div>'
	fh.write(p7)
	p8 = '\n' + strspace + '</div>'
	fh.write(p8)
	flag_tc = False





print("\n\n************  Printing Dictionary key value pairs: ***********\n\n")


fin = open("js_file.txt", "r")
data2 = fin.read()
fin.close()
fh.write("\n\n")
fh.write(data2)
fh.close()


for k, v in dict.items():
	print (k , "=>", v)
	print ("\n")
