import codecs
from bs4 import BeautifulSoup
import requests, re


f = codecs.open("concise_new.html", 'r', 'utf-8')

line1 = '<div class="split right">'
line2 = '<div class="tab-content">Osprey Test Summary</div>'

fd = open("append.html", "w")

fd.writelines("%s\n%s\n" % (line1, line2))

strspace = " "

tc_count  = 1


for line in f.readlines():
	
	if (re.match(r'<tr.*?>', line) and ("Summary" in line)):
		mystring = line
#		print ("Mystring: ", mystring)
		x = re.sub('<[^>]*>', '', mystring)
#		print (x)
		x = x.rstrip("\n")
	
		ts  = '\n' + 4*strspace + '<p>' + x + '</p>'		
		

		gs = ''.join('\n'+ 4*strspace + '<div id="section-tc'+  str(tc_count) + '"' + 'class="tab-content">')
		
		fd.write(gs)
		fd.write(ts)
		ds = '\n' + 4*strspace + '</div>\n'
		fd.write(ds)
		

