import scraperwiki           
import lxml.html
html = scraperwiki.scrape("")
root = lxml.html.fromstring(html)

print (root)

#for el in root.cssselect("div.featured a"):           
#    print (el)


for el in root:           
    print (el.tag)
    for el2 in el:
        print ("--", el2.tag, el2.attrib)



#for el in root.cssselect("div.featured a"): 
#	print (lxml.html.tostring(el))
