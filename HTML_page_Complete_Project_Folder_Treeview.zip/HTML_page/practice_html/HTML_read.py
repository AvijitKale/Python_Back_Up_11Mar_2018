import codecs
from bs4 import BeautifulSoup
import requests, re

#soup = BeautifulSoup(open("concise_new.html"), 'html.parser')

f = codecs.open("concise_new.html", 'r', 'utf-8')

h1_flag = True
h2_flag = True

for line in f.readlines():
	print (line)
	if re.match(r'<h1.*?>', line) and h1_flag:
		p = re.compile(r'<([^\s]+)(\s[^>]*?)?(?<!/)>')
		print (p.sub('', line))
		h1_flag = False
		h2_flag = True	
		if re.match(r'<h2.*?>', line) and h2_flag:
			print ("=================================== I am in H2 loop")
			q = re.compile(r'<([^\s]+)(\s[^>]*?)?(?<!/)>')
			print(q.sub('', line))
#			if re.match(r'<h1.*?>', line):
#				h2_flag = False 
#				h1_flag = True
	

