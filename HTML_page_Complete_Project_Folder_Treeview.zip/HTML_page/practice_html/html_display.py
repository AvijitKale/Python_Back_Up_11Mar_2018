from IPython.display import HTML
from bs4 import BeautifulSoup
soup = BeautifulSoup(open('concise_new.html'), 'html.parser')


while soup:
	h1_list =  soup.find('h1')
	print h1_list
	

