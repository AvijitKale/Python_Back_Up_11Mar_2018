from lxml.html import fromstring
import lxml.html as PARSER

data = open('concise_new.html').read()
root = PARSER.fromstring(data)


global ele

def h1():
	for ele in root.getiterator():
    		if ele.tag == "h1":
        		print (ele.text_content())
		if ele.tag == "h2":
			h2()	

def h2():
	for ele in root.getiterator():
		if ele.tag == "h2":
			print (ele.text_content())
		if ele.tag == "h1":
			h1()

h1()
