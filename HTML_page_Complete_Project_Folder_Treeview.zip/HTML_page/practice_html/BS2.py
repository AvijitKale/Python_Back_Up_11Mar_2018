from bs4 import BeautifulSoup
mytxt = """
<h1>Hello World</h1>
<p>This is a <a href="http://example.com">link</a></p>
"""
soup = BeautifulSoup(mytxt, 'lxml')
mylink = soup.find('a')
