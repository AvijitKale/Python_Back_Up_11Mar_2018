from IPython.display import HTML
from bs4 import BeautifulSoup

TestHTML = """
	<!DOCTYPE HTML PUBLIC '-//W3C//DTD HTML 4.01 Transitional//EN'>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>testplan Osprey Full Functional Test Plan</title>
<link type="text/css" rel="stylesheet" href="http://pnqtestlink01/testlink/gui/themes/default/css/tl_documents.css" />
<style type="text/css" media="print">.notprintable { display:none;}</style>
</head>
<body>
<div>
<div style="float:right;">TestLink Community [configure $tlCfg-&gt;document_generator-&gt;company_name]</div>
<div>Osprey</div><hr />
<p style="text-align: center;"><img alt="TestLink logo" title="configure using $tlCfg->document_generator->company_logo" height="53" src="http://pnqtestlink01/testlink/gui/themes/default/images/company_logo.png" /></div>
<div class="doc_title"><p>Osprey Full Functional Test Plan</p><p>Test Plan</p></div>
<div class="summary"><p id="prodname">Project: Osprey</p>
<p id="prodscope">Project Scope: <p>This project is specific to Osprey software test plan.</p></p>
<p id="author">Author: abagade</p>
<p id="printedby">Printed by TestLink on 15/01/2018</p></div>
<div class="pagefooter" id="copyright">2009 &copy; TestLink Community</div>
<h1 class='doclevel'>Test Suite : BMC</h1>
<h2 class='doclevel'>Test Suite : Web UI</h2>
<p>&nbsp;</p><div> <table class="tc" width="90%" ><tr><th colspan="3">Test Case OSP_SW-3590: IPMI_Web_Login</th></tr>
<tr><td colspan="3"><span class="label">Summary:</span><br /><p>Login to IPMI&nbsp;web browser successful through computer connected to BMC&nbsp;network</p></td></tr><tr><td width="20%" valign="top"><span class="label">Execution type:</span></td><td colspan="2">Manual</td></tr>
<tr><td colspan="3"></td></tr></table>
</div>
<p>&nbsp;</p><div> <table class="tc" width="90%" ><tr><th colspan="3">Test Case OSP_SW-3012: BMC_upgrade_via_WebUI</th></tr>
<tr><td colspan="3"><span class="label">Summary:</span><br /><p>Upgrade BMC using the Megarac WebUI</p></td></tr><tr><td width="20%" valign="top"><span class="label">Execution type:</span></td><td colspan="2">Manual</td></tr>
<tr><td colspan="3"></td></tr></table>
</div>
<p>&nbsp;</p><div> <table class="tc" width="90%" ><tr><th colspan="3">Test Case OSP_SW-3813: BMC_Firmware_Dual_Image_Support</th></tr>
<tr><td colspan="3"><span class="label">Summary:</span><br /><p>Check through Web GUI whether BMC supports dual image for fail safe</p></td></tr><tr><td width="20%" valign="top"><span class="label">Execution type:</span></td><td colspan="2">Manual</td></tr>
<tr><td colspan="3"></td></tr></table>
</div>
<p>&nbsp;</p><div> <table class="tc" width="90%" ><tr><th colspan="3">Test Case OSP_SW-236: BMC_Firmwareupgrade_WebUI</th></tr>
<tr><td colspan="3"><span class="label">Summary:</span><br /><p>Upgrade the on board BMC firmware to the latest one - released one.</p></td></tr><tr><td width="20%" valign="top"><span class="label">Execution type:</span></td><td colspan="2">Manual</td></tr>
<tr><td colspan="3"></td></tr></table>
</div>
<p>&nbsp;</p><div> <table class="tc" width="90%" ><tr><th colspan="3">Test Case OSP_SW-3594: BMC_Java_SOL</th></tr>
<tr><td colspan="3"><span class="label">Summary:</span><br /><p><span style="font-size: small;"><span style="font-family: Verdana;">Java SOL is used to view the host console screen using the SOL Redirection. Java Runtime Environment (JRE) or Java Development Kit (JDK) is required to start Java SOL session. To open Java SOL page from Web UI, click Remote Control &agrave; Java SOL from the menu bar.</span></span></p></td></tr><tr><td width="20%" valign="top"><span class="label">Execution type:</span></td><td colspan="2">Manual</td></tr>
<tr><td colspan="3"></td></tr></table>
</div>
<p>&nbsp;</p><div> <table class="tc" width="90%" ><tr><th colspan="3">Test Case OSP_SW-3817: SMPMPRO_Firmware_Upgrade_WebUI</th></tr>
<tr><td colspan="3"><span class="label">Summary:</span><br /><p>Upgrade Management processor firmware HPM through HPM capsule - via Web GUI</p></td></tr><tr><td width="20%" valign="top"><span class="label">Execution type:</span></td><td colspan="2">Manual</td></tr>
<tr><td colspan="3"></td></tr></table>
</div>
<h2 class='doclevel'>Test Suite : IPMI Tool</h2>
<p>&nbsp;</p><div> <table class="tc" width="90%" ><tr><th colspan="3">Test Case OSP_SW-183: IPMI_verify</th></tr>
<tr><td colspan="3"><span class="label">Summary:</span><br /><p>Verification of the IPMI stack</p>
<p>This is used for System management and monitoring.</p>
<p>( <b>Intelligent Platform Management Interface)</b></p></td></tr><tr><td width="20%" valign="top"><span class="label">Execution type:</span></td><td colspan="2">Manual</td></tr>
<tr><td colspan="3"></td></tr></table>
</div>
<p>&nbsp;</p><div> <table class="tc" width="90%" ><tr><th colspan="3">Test Case OSP_SW-191: BMC_cpu_temperature</th></tr>
<tr><td colspan="3"><span class="label">Summary:</span><br /><p>Monitor the CPU temperature through the sensors. Report through network connectivity in case temperature goes beyond set limit.</p></td></tr><tr><td width="20%" valign="top"><span class="label">Execution type:</span></td><td colspan="2">Manual</td></tr>
<tr><td colspan="3"></td></tr></table>
</div>
<p>&nbsp;</p><div> <table class="tc" width="90%" ><tr><th colspan="3">Test Case OSP_SW-196: IPMI_check_board_info_version_info_Osprey</th></tr>
<tr><td colspan="3"><span class="label">Summary:</span><br /><p>Check the installed IPMI tool version. Board information etc.</p></td></tr><tr><td width="20%" valign="top"><span class="label">Execution type:</span></td><td colspan="2">Manual</td></tr>
<tr><td colspan="3"></td></tr></table>
"""

soup = BeautifulSoup(TestHTML, 'html.parser')

#print (soup.prettify())

heds = soup.find_all("table", class_="tc")

#print (heds)

data = {}

links = []
for h in heds:
#    print "Line: ", h
    x = h.text.strip()
#    date = h.find(class='doclevel').get_text()
#    x = h.split(":")
    data[h] = x
    print "Text: ", x





#for k,v in data.items():
#	print k, "=>", v

#print (links)


