from html.parser import HTMLParser
from bs4 import BeautifulSoup



soup = BeautifulSoup(open("concise_new.html"), 'html.parser')




class MyParser(HTMLParser):
    
    page_links = set()
    
    def handle_starttag(self, tag, attrs):
        if tag == "h1":
            print ("Yes")



parser = MyParser()

parser.feed(open("concise_new.html"))
