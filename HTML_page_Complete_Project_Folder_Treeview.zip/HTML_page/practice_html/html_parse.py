import codecs
from bs4 import BeautifulSoup
import requests, re

with open("concise_new.html") as f:
	soup = BeautifulSoup(f, 'html.parser')


#soup = BeautifulSoup("concise_new.html", 'html.parser')

head_links=soup.find_all('h1')

list = []


mtag=soup.find("table",attrs={"class"=="tc"})


print (mtag)

for hd in head_links:
	list.append( hd.find_all(('h2'), text= True))


#print (list)
