from lxml.html import fromstring
import lxml.html as PARSER

data = open('concise_new.html').read()
root = PARSER.fromstring(data)



while ele < root.getiterator():
    if ele.tag == "h1":
	print ele.text_content()
	if ele.tag == "h2":
		print ele.text_content()
		if ele.tag == "tr":
			print ele.text_content()
    ele = ele +1
