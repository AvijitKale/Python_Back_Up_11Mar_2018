from bs4 import BeautifulSoup
import re


soup = BeautifulSoup(open("concise_new.html"), 'html.parser')


last = soup.find_all("h1")

print (last)

	
for element in last:
	a = element.find()
	print (a)

