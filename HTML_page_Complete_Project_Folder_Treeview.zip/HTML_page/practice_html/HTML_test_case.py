import codecs
from bs4 import BeautifulSoup
import requests, re

#soup = BeautifulSoup(open("concise_new.html"), 'html.parser')

f = codecs.open("concise_new.html", 'r', 'utf-8')



for line in f.readlines():
#	print (line)
	if re.match(r'<p>.*?>', line):
				
		p = re.compile(r'<([^\s]+)(\s[^>]*?)?(?<!/)>')
		test_case = p.sub('', line)
		if test_case.startswith('Test'):
			print (test_case)


