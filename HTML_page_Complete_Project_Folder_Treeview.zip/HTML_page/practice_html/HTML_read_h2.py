import codecs
from bs4 import BeautifulSoup
import requests, re

#soup = BeautifulSoup(open("concise_new.html"), 'html.parser')

f = codecs.open("concise_new.html", 'r', 'utf-8')

flag = True

dict = {}
h2_list = []
h2_dict = {}
tc_list = []
old_head = None
OneFlag = True


for line in f.readlines():
#	print (line)
	if re.match(r'<h1.*?>', line):
		
		p = re.compile(r'<([^\s]+)(\s[^>]*?)?(?<!/)>')
		h1_head = p.sub('', line).lstrip("Test Suite :")
		print (h1_head)
#		print ("H2 List: ", h2_list)
		h2_list = None
		h2_list = []

	if re.match(r'<h2.*?>', line):
		q = re.compile(r'<([^\s]+)(\s[^>]*?)?(?<!/)>')
		h2 = q.sub('', line)
		
		h2_head = h2.split(":")[1]
		h2_head = h2_head.strip("\n")
		print ("\t", h2_head)
#		h2_list.append(h2_dict)
		dict[h1_head] = h2_list
		h2_dict = {}
		tc_list = None
		tc_list = []
		

	if re.match(r'<p>.*?>', line):
		p = re.compile(r'<([^\s]+)(\s[^>]*?)?(?<!/)>')
		test_case = p.sub('', line)
		if test_case.startswith('Test'):
			test_case = test_case
			print ("\t\t", test_case)
			tc_list.append(test_case)
#		print ("tc_list: ", tc_list)	

		if h2_head not in h2_dict.keys():
			h2_dict[h2_head] = tc_list
			h2_list.append(h2_dict)		
#			print ("H2_dict:", h2_dict)
		

print("\n\n************  Printing Dictionary key value pairs: ***********\n\n")

for k, v in dict.items():
	print (k , "=>", v)
